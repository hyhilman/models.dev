# doppelganger

**AI coding agents that work through your GitHub issues while you are away.**

You write issues. doppelganger picks them up one by one, lets an agent write the code, opens a pull
request, has a second agent review it, merges it when the review and CI pass, closes the issue,
and sends a note to your phone. When an agent gets stuck, it asks you a question on the issue and
waits for your reply.

It also runs other small jobs on a schedule (nightly clean-ups, log reports, health checks).

> Status: early and personal. It runs this repo's own backlog today. Expect rough edges.

To work on the engine itself (run it from its checkout, test it, make a release), see
`CONTRIBUTING.md`.

---

## How it works

     you write an issue  ──►  label: ready-for-agent
                                   │
                                   ▼
            ┌─────────── the flow (every 5 minutes) ───────────┐
            │  1. executor agent writes the code               │
            │     in its own folder                            │
            │     (.worktrees/<name>/<name>-issue-<n>)         │
            │  2. opens a pull request                         │
            │  3. reviewer agent checks it ──► changes? ──► fix│
            │  4. CI green + review pass  ──►  merge           │
            │  5. close the issue, ping your phone             │
            └──────────────────────────────────────────────────┘
                                   │
                 stuck? ──►  label: needs-human  ──►  you reply on the issue

The main pieces:

- **Supervisor**: one long-running process. It starts each job at the time the schedule says. The
  schedule lives in `host/schedule/schedule.ts`.
- **Jobs**: small programs grouped into plugins under `plugins/`. The issue flow is `watch-flow` in
  `host/jobs/`, with its steps in `plugins/github/` and `plugins/coder/` (see "Flows").
- **Agents**: each role of the flow runs on the providers you choose, in order: the pi coding agent,
  OpenAI's codex agent or DeepSeek Harness (dsh), each in a throwaway Docker container with a model and
  credentials you give it, or claude. A pi, codex or dsh agent never sees your home folder.
- **Leases**: small locks in a local database, so two runs never work the same issue at once.

---

## What you get, and what a repo adds

You adopt one engine. A repo runs it one of three ways, and they do not mix in one repo: the
release image, the package, or an engine checkout, which serves many repos from one copy (see
`CONTRIBUTING.md`).

**The image way** runs the engine from the release image built for each version (see "Releases").
`init` writes the `dg` launcher into `.doppelganger/`, and `dg up` pulls the image and starts the
supervisor. The builds follow the branches `dev`, `rc` and `main`. A repo follows the channel `dev`
or `rc`, and `dg update` — the crontab line `dg cron install` adds — moves it to the newest build
of the channel. A repo that pins a stable version moves by setting `version` and running `dg up`.
The image runs the built-in plugins only.

**The package way** installs `doppelganger` in the repo and runs it with `npx doppelganger` (see
"Install it in your repo"). This is the way that loads a project's own plugins, attached in
`doppelganger.config.ts` (see "Add your own plugin"). A plugin may fill three flow slots, and the
engine pools each with what the built-in plugins offer:

- `trackers`: where a flow's work items live. A flow names one kind as its `tracker`.
- `steps`: one unit of flow work on an item, like the built-in `coder` step. A flow lists them in
  order.
- `answerers`: who looks first at a parked item and picks its next move, before a person does.

---

## What you need

- A Linux machine that stays on.
- Node.js, except when you run from the image (see the next section). The exact version is in `.nvmrc`.
- Docker. Rootless Docker is recommended: the agents then never get root on your machine.
- The GitHub CLI (`gh`), logged in to an account that can push to the repo.
- An account with a model provider (for example OpenCode Go, or Claude).
- Optional: an [ntfy](https://ntfy.sh) server or topic, for phone notifications.

---

## Run it from the image

This is the way with the least on your machine: **only Docker**. There is no engine checkout and no
package install. Every release publishes a supervisor image that carries the engine, and `version` in the
repo's committed `doppelganger.toml` picks the image. Each repo can run a different version.

Which way to pick:

- **The image** (this section): a repo that needs nothing from the engine but its built-in plugins. Any
  repo works, Node project or not. This repo runs itself this way, from an `rc`-channel image.
- **The package** ("Install it in your repo"): the repo has its own plugins in `doppelganger.config.ts`, or
  you want the engine version in the repo's lockfile. The image runs the built-in plugins only.
- **The engine checkout** (`CONTRIBUTING.md`): you work on the engine, or one
  checkout should serve many repos.

The images are private, so log in once on each machine, with a GitHub token that has the `read:packages`
scope. Then, in the repo, run `init` from the image of the version you want:

    docker login ghcr.io
    cd ~/code/api
    docker run --rm -it -u "$(id -u):$(id -g)" -v "$PWD:$PWD" -w "$PWD" \
      ghcr.io/hyhilman/doppelganger-supervisor:0.1.0-dev.3 init

`dg` starts the supervisor on the docker daemon your `docker` command uses by default, as `bin/fleet.sh`
does, and only the passes use the rootless daemon. It refuses to start the supervisor on a rootless
daemon, because there the container's user maps to another user on the machine and cannot read the
secret file or the credentials. If your shell sets `DOCKER_HOST` to the rootless socket, unset it for `dg`.

`init` runs inside the repo, so it needs no path. The image name is the one a release prints (see
"Releases"). Add `-e INIT_DRY_RUN=1` first to see what it would do without writing anything. It writes:

- `doppelganger.toml`, with `version = "0.1.0-dev.3"` (the version of the image that ran) and the
  settings `init` can derive. Commit it. It holds no secret;
- `doppelganger.secret.toml`, mode 600, for your tokens. Git ignores it;
- three files under `.doppelganger/`: the compose file, the `dg` launcher and the watchdog. They hold
  no edit of yours, so `init` writes them again every run, and each has a header that says so. Git
  ignores the folder.

`init` never overwrites `doppelganger.toml` or `doppelganger.secret.toml`. When one exists, it lists the
lines to add. It makes no tracker labels, because a one-shot container has no `gh` login. The next steps
it prints are these, and every command after the first is the `dg` launcher in the repo:

    .doppelganger/dg creds add gh my-github        # a GitHub login, kept in this repo's .doppelganger/creds/
    .doppelganger/dg creds gh-login my-github
    .doppelganger/dg labels                        # the tracker labels, with that login
    .doppelganger/dg up                            # pull the image, start the supervisor (a dry run at first)
    .doppelganger/dg logs -f
    .doppelganger/dg cron install                  # the watchdog entry (and the update entry of a channel) on this machine's crontab

Before `labels`, set `gh = "my-github"` under `[exec]` in `doppelganger.toml`, and `humans` under your
flow. Set `test_cmd` in the change step table of your flow to the repo's test command. Set `build_cmd`
there too when the repo has a build of its own: the step runs it in the item's worktree before its
pass, and a build that fails parks the item with the output, before a fix round spends a pass on it.
A build is cut off after `build_timeout_min` minutes (5 by default, at most 60), and the item then parks as timed out.
The agents run on claude by default. To run on pi or codex, add the entries
that "Choose who does the work" describes, and make their logins with `dg creds add pi <name>` and
`dg creds login <name>`. The pi image goes with the release: the engine in the supervisor image names
it, and `dg up` pulls it on the machine, because the container has no registry login of its own (see
"The pi image" below). To pull it by hand, for example before the first `dg up`:

    docker pull ghcr.io/hyhilman/doppelganger-pi:0.1.0-dev.3

No release publishes the codex image. Build it once on each machine that runs a codex entry:
`.doppelganger/dg runner build codex`.

### Upgrade

Set `version` in `doppelganger.toml` to the new release, commit it, and run `.doppelganger/dg up`. `dg`
sees that the pin is not the version it was made from. It asks the pinned image to write the launcher,
the compose file and the watchdog again (`init --refresh`), starts over with the new launcher, pulls the
new image and restarts the container. `dg up` pulls the new pi image as well.

A supervisor or a job whose engine is not the pinned version refuses to start, and the message names
both versions. That also stops a stale container from running after you changed `version`.

`version` takes one of two things: an exact version such as `0.1.0-rc.1`, or a channel: `dev` or `rc`. Any
other word (`latest`, `0.1`) is refused, and the message names the two forms.

### The pi image

A release runs the pi image published for its own version, unless `image` under `[runner.pi]` is set.
The supervisor container has no registry login, so the pi image has to be on the host. `dg up` and
`dg update` do that: they ask the pulled supervisor image which pi image it expects, with `docker run
--rm <image> version --images`, and pull that one on the host with `docker pull`, into the rootless
daemon where the supervisor starts the pi passes. They do it for an exact pin and for a channel. A pull that fails stops `dg up` before it starts the supervisor, and
refuses `dg update` (see below).

- They pull it always, whether or not the repo has a pi entry. A repo without pi entries pays one small
  pull.
- When `image` under `[runner.pi]` is set, in `doppelganger.secret.toml` or `doppelganger.toml`, the image
  is yours: `dg` neither asks nor pulls, and you keep it on the host yourself.
- They pull a reference only of the form `<registry>/<name>:<exact version>`. An image that names no
  such reference (a local build that no release stamped) gets no pull.
- `DG_NO_PULL=1` skips this pull too.

### Follow the dev channel

With `version = "dev"` a repo runs the newest dev build, with no edit in the repo. A dev build is a
button on the `dev` branch (see "Releases"): it moves the image tag `dev` to that commit, and this
repo follows that tag. A push to `dev` builds nothing. The engine's own repo follows `rc`, the same
way: `rc` moves once per finished phase (see "Release phases"), and the running supervisor takes the
new candidate within the hour, so a bad candidate reaches it too. **Every other repo should pin an
exact version**, and change it on purpose: a commit, then `dg up`.

How it works:

- The image tag is the pin itself, so `dg` and the compose file use the tag `dev`, and `version = "dev"`
  makes no check of the engine's version at boot. The supervisor and `npm run job` log one info line
  (`version-pin-channel`) with the engine's own version and the channel.
- The tag stays `dev` while the image behind it changes, so after a pull `dg up` asks the pulled image
  which release it holds, with `docker run --rm <image> version`. No supervisor starts for this. When
  that release is not the one the launcher was made from, the pulled image writes the launcher, the
  compose file and the watchdog again, as for a new exact pin.
- `dg cron install` adds a second line to the managed crontab block: `dg update` at minute 8 of every
  hour. The watchdog runs at minutes 3, 18, 33 and 48. An exact pin installs no update line, and
  `dg cron install` takes the line out again when the pin stops being a channel (`dev` or `rc`).
  Until then `dg cron check` reports drift.

`dg update` is the step the crontab line runs. You can run it by hand. It does this:

1. It pulls the pinned image. If the image the container runs is the one it pulled, it logs `up to
   date` and stops. The same holds for an exact pin, where the pull rarely brings anything new. (A
   current image pulls no pi image.)
2. It stops if the last update of this very image did not start (see the rollback below).
3. **The check before the switch.** The new image runs once, with `docker run --rm` (not compose), on this
   repo with a read-only mount: `config check`. It makes the checks of the settings that the supervisor
   makes at boot: the plugin choice, the version pin, unknown keys, keys that must not be in the shared
   file, a token in it, and each plugin's own check, such as the todo plugin's role entries. If the
   check fails, the old image stays. `dg` logs `update refused: config` and one line for each reason,
   with the key and the path and never a value that looks like a secret, and exits 0, so the next
   hour asks again. Fix the settings, or wait for a newer image.
4. **The pi image.** It pulls the pi image of the new release on the host (see "The pi image"). If that
   pull fails, the supervisor would fail every pi pass after the switch, so the old image stays: `dg`
   logs `update refused: pi image` with the reference and the reason, and exits 0. The next hour tries
   again. This comes before the wait, next to the check above.
5. It waits for the supervisor to be idle: no job process is alive and no agent run is in flight. It
   reads `.doppelganger/supervisor.status.json`, which the supervisor writes every minute and when a job
   starts, with `grep` and `cut`. The host needs no node and no jq. It looks every 30 seconds, for up to 30
   minutes. When it finds the supervisor busy, it writes `.doppelganger/pause` first: the supervisor
   starts no new job while the ones that run finish.
   The file holds the time the pause ends, a little after the wait would, so a killed `dg update`
   cannot hold the work back for long. Every end of `update` removes it. If the supervisor never goes idle, it logs `update waits: busy` and exits 0, so the next
   hour tries again. A status file that is missing or older than 5 minutes, or a container that is not
   running, counts as idle, because nothing is running. A status file that cannot be read counts as
   busy.
6. When idle, it writes the launcher files again from the new image if its release differs, and runs
   `docker compose up -d`, which recreates the container on the new image. It logs the old and the new
   release.
7. **The rollback.** Before it recreates the container, `dg` keeps the old image under the local tag
   `dg-rollback`. After the switch it waits up to 5 minutes for a heartbeat that is newer than the
   switch. 5 minutes is the age at which the watchdog calls a heartbeat stale, and a normal boot writes
   the first heartbeat within seconds. If none comes, or `up -d` fails, `dg` writes the id of the new
   image to `.doppelganger/update.bad`, has the old image write the launcher files back when the
   release changed, recreates the container on `dg-rollback`, logs `update rolled back` with the old
   and the new release, and exits 1. Later runs skip an image with the recorded id: `update` waits for a
   newer one, and `dg up` refuses to start it and names the file to delete to try it anyway. A different
   (newer) image clears the file. Delete the file by hand to try the same image again.

Every event is one logfmt line in `.doppelganger/logs/dg-update.log`, in the shape of the repo's other logs.
Error lines there reach the log report like any other. A lock file, `.doppelganger/update.lock`, keeps
two updates from running at once.

These variables of the launcher are not settings of the engine, like `DG_IMAGE` and `DG_NO_PULL`
(which `update` honours too):

- `DG_UPDATE_DRY_RUN=1` pulls (both images), runs the check, looks once at the supervisor, prints what it
  would do, and changes nothing: no switch, no log file, no lock, no kept image.
- `DG_UPDATE_POLL_S` (30), `DG_UPDATE_IDLE_WAIT_S` (1800) and `DG_UPDATE_BOOT_WAIT_S` (300) are the
  seconds it looks, waits for idle, and waits for the first heartbeat. The defaults are right for real
  use. A test sets them small.

### The commands

`dg` runs the commands that need the engine in a throwaway container of the pinned image, so they work
whether or not the supervisor is up.

    .doppelganger/dg up              pull the pinned image and its pi image, then start the supervisor
    .doppelganger/dg serve           pull the same, then start the scheduler of a fleet, instead of `up`
    .doppelganger/dg add [N]         add N workers to the running fleet, on the image it runs
    .doppelganger/dg rm [N]          remove N workers
    .doppelganger/dg down            stop and remove every container of this repo, the fleet too
    .doppelganger/dg restart         restart the container
    .doppelganger/dg logs -f         follow its output
    .doppelganger/dg status          the facts dg starts it with, and what is running
    .doppelganger/dg pull            pull the pinned image
    .doppelganger/dg update          pull the pinned image and its pi image; if it is new, wait for an idle supervisor and switch to it
    .doppelganger/dg job <name>      run one job by hand
    .doppelganger/dg list            the jobs this repo runs
    .doppelganger/dg dlq             list or revive the rows that died
    .doppelganger/dg lease-clear     free a lease by hand
    .doppelganger/dg quota-clear     list the quota breakers not lifted, or lift one by hand
    .doppelganger/dg smoke           one tiny call to every credential and model the roles name
    .doppelganger/dg labels          create the tracker labels with the repo's own gh login
    .doppelganger/dg creds ...       the credential store (bin/creds.sh, run in the image)
    .doppelganger/dg runner ...      the runner images (bin/runner.sh, run in the image)
    .doppelganger/dg usage up        start the usage viewers the [usage] ports turn on; down stops them
    .doppelganger/dg api up          start the instance API on 127.0.0.1; down stops it, status shows it (see "The web site")
    .doppelganger/dg web up          start the web hub on 127.0.0.1; down stops it, status shows it
    .doppelganger/dg squad-web up    start squad web on the shared squad home (needs DG_SQUAD_HOME); down stops it, status shows it
    .doppelganger/dg token add <hub> make the token of a hub and print it once; revoke <hub> ends it, list shows them
    .doppelganger/dg cron install    put the watchdog, and for the channel dev the hourly update, on this machine's crontab
    .doppelganger/dg cron check      say whether those entries match this version
    .doppelganger/dg watchdog        run the watchdog once, now
    .doppelganger/dg help            this list

`cron install` uses the image's own crontab tool on a copy of your crontab, and installs the copy with the
machine's `crontab` program. Every line outside the managed block stays as it was. It stops with a message
when the machine has no `crontab`. The entry runs `.doppelganger/watchdog.sh`, a copy of `host/watchdog.sh`
that needs bash and system tools only: it does not look for node or the engine on the machine, because
they are in the image. It still checks the heartbeat and the delivery stamps, and sends the ntfy message.

To keep a `claude rc` (remote control) session running in the repo, set `[crontab] rc = true`.
`cron install` then adds a line that starts `claude rc` in a tmux session every minute the session is
gone. The session is named after the repo's folder; `rc_session` names it something else, and
`rc_spawn` picks its `--spawn` mode (`same-dir` when empty). A line you wrote by hand in the same shape makes `cron install`
stop and name it; `dg cron install --adopt` takes it over.

### What the image does not run

- **Your own plugins.** The image runs the built-in plugins only. A plugin of your own imports the
  package, which this way does not put in the repo. A repo with a `doppelganger.config.ts` should
  install the package instead.
- **`git`.** It fast-forwards the checkout the supervisor runs from, which is inside the image and
  not the repo (see "What a repo does not run" in `CONTRIBUTING.md`). The `nightly` plugin runs:
  its polish job only files an issue, and the repo's own `[flow.night]` flow works it. Jobs that
  still fit the engine's own source alone (the `nightly-sandcastle` job) are dropped wherever a
  project runs.
- **Anything of the older ways.** The engine is not mounted from the machine, so `bin/fleet.sh` and
  `npm run` commands are not part of this way.

Two things you may see in the repo that you did not make. `.doppelganger/engine/<version>/` holds a copy
of the skills for the pi runner, made once per version: the pi container is started by your machine's
docker daemon, which cannot see the engine inside the image. And `.doppelganger/crontab.work` exists for
a moment while `cron install` runs.

For a build that is not in a registry, `DG_IMAGE=<name>` runs another image name, and `DG_NO_PULL=1` skips
the pull.

---

## Install it in your repo

A repo with a `package.json` can install doppelganger as a package. It then runs the engine, adds
its own plugins and turns built-in plugins off. Nothing goes to a registry: you install from a git
URL, a folder or a tarball.

Which one to pick:

- **The package** (this section) when you want your repo's own plugins, or want the engine version
  pinned in the repo's lockfile. The engine lives in the repo's `node_modules`, so the container
  needs no separate engine mount.
- **The engine checkout** ("Run it on your other repos" in `CONTRIBUTING.md`) when one engine
  checkout should serve many repos, when a repo is not a Node project, or when you work on the engine
  itself.
- **The image** ("Run it from the image") when the repo needs only the built-in plugins and you want
  nothing but Docker on the machine.

### Let your agent do it

`INSTALL.md` is a guide for a coding agent. It installs a release tarball, adds one plugin of the
repo's own, and checks that the plugin runs. In your repo, give your agent this prompt:

    Enable doppelganger in this repo. Read the guide with
    gh api 'repos/hyhilman/doppelganger/contents/INSTALL.md?ref=dev' -H 'Accept: application/vnd.github.raw'
    and follow it.

The repo is private, so the agent reads the guide with `gh`, and its `gh` login must be able to read
this repo. The agent asks you what it needs, and hands you the steps that need a login or a token.

### Install it and set it up

In your repo:

    npm install -D github:hyhilman/doppelganger#dev
    npx doppelganger init

That installs a branch. To pin a version, install a release instead (see "Releases"). `init` then
writes a compose file that pulls the published image of that version, where a branch install builds
the image on your machine.

`init` does what it does for the engine checkout (see "Set a repo up" in `CONTRIBUTING.md`), with
two changes. You run it inside the repo, so it needs no path. And the engine is
`node_modules/doppelganger`, a folder the repo mount already covers, so the compose file has no engine mount. Add `INIT_DRY_RUN=1`
first to see what it would do. Then follow the steps it prints. Init writes `doppelganger.toml`, which you
commit, and `doppelganger.secret.toml`, which git ignores and which holds your tokens.

Other ways to install:

- A tarball. In an engine checkout run `npm pack`, then in your repo `npm install -D <path to the .tgz>`.
- A folder. `npm install -D <path to the checkout>` only links the folder. The engine code is built
  by `npm run build`, and the link finds its libraries in the checkout, so run `npm install` and
  `npm run build` in the checkout first.

The package is private, so `npm publish` fails on purpose. `npm run build` compiles the engine into
`dist/`, because Node does not strip types under `node_modules`. `npm pack` and a git install run it
for you. While you work on the engine itself, nothing is built: Node runs the TypeScript files.

### The commands

    npx doppelganger init            set the repo up (once)
    npx doppelganger config migrate  move an old setup: .env or a one-file doppelganger.toml, and creds/
    npx doppelganger --list          the jobs this repo runs, built-in and attached
    npx doppelganger job <name>      run one job by hand
    npx doppelganger up              run the supervisor on this machine
    npx doppelganger version         print the release version of this engine, or with --images the pi image of it (a checkout has neither)
    npx doppelganger skills sync     render the skills this repo runs into .claude/skills
    npx doppelganger crontab sync    install the watchdog on the machine's crontab
    npx doppelganger lease-clear     free a lease by hand
    npx doppelganger quota-clear     list the quota breakers not lifted, or lift one by hand
    npx doppelganger smoke           one tiny call to every credential and model the roles name
    npx doppelganger dlq             list or revive the rows that died
    npx doppelganger api             serve the read-only instance API on loopback, for a hub to read through a tunnel
    npx doppelganger token add <hub> make the token one hub uses to read the instance API; revoke and list too
    npx doppelganger web             serve the web hub: the web app, the sign-in and a read-only view of every workspace
    npx doppelganger usage up        start the usage viewers the [usage] ports turn on; down stops them
    npx doppelganger help            this list

`up` runs the supervisor on the host. The container does the same job: use
`docker compose -f .doppelganger/compose.yml up -d`. Run one of the two, never both.

`npx doppelganger config check` runs the checks of the settings that the supervisor makes at boot, and
starts nothing. It prints one `config-problem:` line for each problem, and never a value that looks
like a secret. It exits 1 when it finds one.

The settings come from `doppelganger.toml` and `doppelganger.secret.toml` in the repo, and a variable
of the same name beats both files for one run, as with `npm run job`. The repo is the current folder; `PROJECT_ROOT` names another.

### Add your own plugin

List your plugins in one file at the top of the repo, `doppelganger.config.ts`. The engine imports
that file when it starts, and nothing else: it never scans a folder. The file and your plugins are
TypeScript in your repo, so Node runs them as they are. Set `"type": "module"` in your
`package.json`. The field is not only for Node: without it, under `nodenext`, TypeScript takes
`doppelganger.config.ts` and your plugin files as CommonJS, so an editor and `tsc` fail the type
check on every `import` line in them, while the engine still runs them.

    import { defineConfig } from "doppelganger/plugin";
    import hello from "./tools/hello/plugin.ts";

    export default defineConfig({ plugins: [hello] });

To use your own procedure for a job, add `skills` to the same config. A key is the job name, and a
value is the folder that holds the job's skill file, relative to the repo (or an absolute path
inside it). `npx doppelganger skills sync` renders that folder instead of the plugin's, and the
managed marker names it. `npx doppelganger skills check` reports `override-orphan` when a key names
no job that runs a skill. The override changes the prompt only: the job's permissions and the output
its code parses stay in code.

    export default defineConfig({
      plugins: [hello],
      skills: { "todo-change": "./skills/todo-change" },
    });

A plugin is a manifest with its jobs. This one has one job that runs plain code:

    import { definePlugin } from "doppelganger/plugin";
    import { defineJob } from "doppelganger/ports/job";

    const greet = defineJob({
      name: "ops-hello-greet",
      description: "Write one line to the log",
      plugin: "hello",
      permissionMode: "auto",
      exec: async (ctx) => {
        ctx.log.info("hello", { from: "my own plugin" });
      },
    });

    export default definePlugin({
      name: "hello",
      kill: [],
      sources: [],
      routes: [],
      jobs: [greet],
      schedule: [],
      env: [],
      trackers: [],
      steps: [],
      answerers: [],
      forges: [],
      dir: import.meta.dirname,
    });

Then `npx doppelganger --list` shows `ops-hello-greet` with the mark "attached", and
`npx doppelganger job ops-hello-greet` runs it. Its databases and logs go in your repo
(`.doppelganger/`), never in `node_modules`.

An attached plugin follows the same rules as a built-in one. The engine checks them when it loads
the file, and refuses to start with the list of what is wrong:

- The plugin name is lower case, and no other plugin has it. `dir` is the plugin's own folder, so
  write `import.meta.dirname`.
- A job name starts with a stage prefix: `source-`, `triage-`, `backlog-`, `watch-`, `todo-`,
  `corpus-`, `nightly-`, `retro-` or `ops-`. No other job has the name. A job has a skill, code
  (`exec`) or both.
- One skill per job. A skill lives in `skills/<job>/SKILL.md` inside the plugin's folder, and no
  folder is left over without a job.
- Every setting is a row with a one-line `why`. A kill switch is named in capitals: the plugin, then
  NO, then the feature, joined by underscores. Build it with `killSwitch`.
- A job may carry a schedule entry: it names one of the plugin's own jobs, with a stage-prefixed
  name, a 5-field cron, an absolute `log` path under the project's `.doppelganger/logs/` folder (or
  a logs folder at the project's root) and a one-line `why`. The supervisor runs each entry under the same gate as a built-in
  job — its own `excl+self` row over every resource, which the entry cannot opt out of — and
  refuses an entry that sets `supervised: false` or names a `script`. A job the plugin does not
  schedule still runs by hand: `npx doppelganger job <name>`. Leave the example plugin's
  `schedule` as `[]` when it has nothing to run on a clock.

Your plugins can import `doppelganger/plugin` and `doppelganger/ports/*` and nothing else. A deep
import of any other path fails on purpose. The one other export, `doppelganger/contracts`, is only for
a host's test file. The contract suite flags it when a plugin imports it.

### Turn plugins off

`plugins` in the repo's `doppelganger.toml` names the plugins that run, built-in and attached. Leave it
out and every plugin runs, except `git`, which only fits the engine's own source. `init`
sets `plugins = ["github", "coder", "todo", "ops"]`, because the other built-in plugins need settings of their own. To run
your plugin as well, add its name: `plugins = ["github", "coder", "todo", "ops", "hello"]`. See "Choose which plugins
run" for the rest of the rules. `npx doppelganger --list` ends with the plugins `plugins` leaves out.

### Upgrade

For a release, follow "Releases / Upgrade" below. For a branch install, install again (`npm update
doppelganger`, or `npm install -D github:hyhilman/doppelganger#dev` for a newer branch), then restart: `docker compose -f .doppelganger/compose.yml down` and `up -d`.
If the `Dockerfile` changed, build the image again. If `.nvmrc` changed, the image has a new
name: delete the compose file and run `init` again.

---

## Settings

From here on, a command is written the way an engine checkout runs it: `npm run job`, `bin/creds.sh`,
`bin/runner.sh`. From the image, run the same through `.doppelganger/dg` (`dg job`, `dg creds`,
`dg runner`, `dg lease-clear`). From the package, use `npx doppelganger` (see "The commands" under
"Install it in your repo").

Settings live in two files in the repo folder. Nothing reads a `.env` file.

- `doppelganger.toml` is committed. It holds the settings your team shares, and no secret.
- `doppelganger.secret.toml` is not committed (git ignores it). It holds tokens, and any value that
  differs on this machine, such as `cmd` under `[crontab]`.

`init` writes both files from the examples, with every setting's one-line comment. The examples
show each default as a commented-out line: remove the `#` only to change one. A small
`doppelganger.toml` is enough:

    plugins = ["github", "coder", "todo", "ops"]

    [flow]
    dry_run = true

    [flow.widgets]
    tracker = "github"
    repo = "acme/widgets"
    steps = ["coder", "github.merge"]
    humans = ["your-github-login"]

    [ntfy]
    url = "https://ntfy.example.com"

    [crontab]
    cmd = "/usr/bin/crontab"

Put the token in `doppelganger.secret.toml`:

    [ntfy]
    token = "tk_your_token"

A secret setting is set in the environment or in `doppelganger.secret.toml`, never in
`doppelganger.toml`. There are two: `NTFY_TOKEN` and `JIRA_API_TOKEN`. The supervisor and `npm run
job` refuse to start when `doppelganger.toml` sets one, or holds any value that looks like a token
(a GitHub token, an API key, a long run of letters and digits). The message names the file and the
key, never the value. `doppelganger.secret.example.toml` lists the secret settings. A setting that is
not secret may sit in either file, and the secret file wins when both set it. The one thing the
secret file cannot hold is a `[[...]]` list of tables, such as `[[exec.executor]]`: those stay in
`doppelganger.toml`.

A key is the name of its setting, in lower case. The first word is the table, and the rest is the key,
so `FLOW_DRY_RUN` is `dry_run` under `[flow]`, and `PLUGINS` is `plugins`, with no table. A key in
either file that is not a setting stops the supervisor and `npm run job` when they start, so a typo
never passes in silence.

A setting name a release retired is refused in the environment too: a process that still sets the
sandcastle merge switch's former name (NIGHTLY_SANDCASTLE_NO_MERGE, now NIGHTLY_NO_SANDCASTLE_MERGE)
or the dead-letter queue alarm's (BACKLOG_DLQ_MAX, now SWITCH_DLQ_MAX) refuses at start instead of
reading as unset.

For one run, an environment variable beats both files. `FLOW_DRY_RUN=1 npm run job watch-flow` runs the
flow once in dry run, whatever the files say. The order is: the environment, then
`doppelganger.secret.toml`, then `doppelganger.toml`, then the default. Each key that the environment
and a file both set is logged at start as `settings-override`, with the key and never its value. Two
settings come from the environment only: `PROJECT_ROOT` (the repo to work on) and `DOPPELGANGER_CONFIG`
(the path of `doppelganger.toml`, or `none` for no file; the secret file is the one in the same
folder).

Only settings go in these files. A variable that is not a setting, such as a login token for another
tool, is not read from them. In the container, set it under `environment:` in the compose file. On the
host, set it in your shell.

A change to either file is read by the next round, with no restart. `plugins` and the `[supervisor]`
settings are the exception: restart the supervisor.

### Upgrade from the older layout

Older versions kept every setting in a `.env`, and later in one gitignored `doppelganger.toml` that
held the tokens too, with the logins in `creds/` at the repo root. Stop the supervisor, then run
`npm run config -- migrate` (add `CONFIG_DRY_RUN=1` first to see what it would do). It does up to
three jobs, and never prints a value:

- With a `.env`, it writes `doppelganger.secret.toml` (the secret settings, mode 600) and
  `doppelganger.toml` (all others, mode 644) from it, and leaves `.env` as it is. It names every key
  it could not carry over. Check the new files, then delete `.env`. It never overwrites either file.
  The old runner row and the models and credentials of each role become `[[exec.<role>]]` entries:
  when the runner was `pi`, each model is one entry (see "Credentials"). Under claude those rows were
  never read, so they make no entry.
- With no `.env`, it looks at a `doppelganger.toml` from before the secret file, and moves its secret
  rows to a new `doppelganger.secret.toml`. It cuts out only the lines of those rows, so the comments
  stay. When it cannot cut a row (written as a dotted key, an inline table, or over many lines), it
  writes the file again from its content, and says that the comments are lost. It stops, and tells
  you which keys to move, when `doppelganger.secret.toml` already exists.
- It moves `creds/` to `.doppelganger/creds/` with one rename. It stops, naming both folders, when
  both exist.

It then tells you what to change in `.gitignore`: add `doppelganger.secret.toml` and `.doppelganger/`,
and remove `doppelganger.toml`, so the file can be committed.

The issue flow reads its settings from the same file: the flow tables, and `[flow]` for the settings
of the engine (see "Flows"). The role settings stay under `[exec]`. The ones to set first:

| Key | What it is |
|---|---|
| `[flow.<name>]` | One table per flow: its `tracker`, the `repo`, the `steps` and the `humans` whose reply frees a parked item. See "Flows". |
| `[flow.<name>.coder] base` | The branch the pull requests of the change step go to. Unset, each repo's own default branch. |
| `[flow.<name>.coder] forge` | The code host the change step opens and reviews pull requests on, by the name a plugin gave its forge. Default `github`. |
| `[[exec.executor]]` | One entry per provider, tried in order. The same for `[[exec.reviewer]]`, `[[exec.smart]]` and `[[exec.cheap]]`. With none, each role runs on claude with the job's own model (see "Credentials"). |
| `[exec] gh` | The name of the GitHub login under `.doppelganger/creds/gh/` that the flow and its agents use (see "Credentials"). |
| `[exec] prices_url` | The catalog (a models.dev style JSON file) that finds the providers of a routed entry and puts them in price order. `ops-models-sync` reads it too (see "Credentials"). Empty (default) = a routed entry is reported as a problem at start, and no model list is synced. |
| `[exec] models_sync_dry_run` | `0` (default). `1` makes `ops-models-sync` log what it would change and write nothing. |
| `[exec] price_watch_min_usd` | `2` (default). `ops-price-watch` posts once a day when another provider in the catalog would run the models your runs used for at least this many dollars a week less (see "Credentials"). |
| `[flow] dry_run` | `true` (default) only logs. Set `false` to go live. |
| `[ntfy] url` | Your ntfy server, if you want phone notifications. Its `token` goes in `doppelganger.secret.toml`. |

A flag is `true` or `false` in the file (`1` and `0` also work, and are what the environment uses).

The loop is named after the checkout folder with a short hash of the checkout's full path (or the
top-level `instance` setting). That name is in its lease keys, its worktree folders and its log
lines, so two checkouts of one repo under different parents on one machine still never share them.

`[crontab] cmd` has no default and is always needed. It is the full path to your `crontab` binary
(run `which crontab`); it differs per machine, so it may go in `doppelganger.secret.toml`. The role
entries have no default, and the flow runs without them: a role with no entry runs on claude.

### Choose which plugins run

By default a checkout runs every plugin under `plugins/`, and every plugin the repo attaches (see
"Install it in your repo"). To run only some, name them in `doppelganger.toml`:

    plugins = ["github", "coder", "todo", "ops"]

The names are the folder names under `plugins/`, and the names of the plugins a repo attaches. Leave
`plugins` out to run them all. Once you set it, it is the whole list: a plugin it does not name is off.

#### The built-in plugins

- `todo`: drafts a tracker issue in the 9-section format, on your word (`/todo-draft`).
- `plan`: the flow's plan step. It writes the implementation plan for one item, and never edits code.
- `coder`: the flow's change step. It writes the change, opens the pull request and runs its review
  and fix rounds.
- `tester`: the flow's test step. It verifies a change in a named environment and returns pass,
  fail or blocked.
- `qa`: the flow's QA step. It waits for a person to move the item to a pass or a fail status.
- `github`: the notifications source, the `github` forge, and the flow's tracker, merge and deploy
  steps for GitHub.
- `jira`: the flow's tracker for Jira.
- `slack`: the Slack source. A mention comes in as a backlog row like every other.
- `notion`: the Notion source.
- `lanes`: the triage switch. It gives every new backlog row a route, in code first, then by asking
  the decider; its probe measures the same question over live rows.
- `ask`: the ticket ask. It turns each conversation on a `ticket:<flow>` route into tickets of that
  flow's tracker.
- `corpus`: the corpus family. `corpus-checklist` harvests human review comments on newly merged
  pull requests and keeps the review checklist current, holding a new cluster on probation until the
  comments hit it; a comment the engine itself wrote is not input, because it opens with a machine
  marker, so the lane never feeds its own review text back into the checklist it is supposed to
  teach. `corpus-refresh` pulls each configured service repo, writes the docs snapshot the
  corpus is built from, runs the runbook command the project sets for a bounded rotation of the moved repos, then runs the lint command the project sets. `corpus-lint` checks every reference root with no model, writes the
  frontmatter a path supplies and each folder's index, pushes the fix, and files one backlog row
  for what it cannot fix.
- `retro`: the weekly retro. It asks whether the last week's judgements were right, lane by lane,
  and records the pass.
- `smart`: the flow's answerer. It looks at a parked item and picks its next move before a person
  has to.
- `stale`: the flow's stale-item answerer. It looks at a parked item whose pull request is already
  merged, and settles it with no model call and no person. A pull request closed without a merge
  asks a person once, naming it. If that person replies and it is still closed, the flow ends on
  the item.
- `ops`: the operator jobs: lease reap, log report, retention, the model list sync, and the read-only
  smoke test. Always needed: a `plugins` list without it is refused.
- `nightly`: the overnight jobs: one small verified improvement (`nightly-sandcastle`) and the repo
  polish pass (`nightly-polish`).
- `git`: fast-forwards the checkout the supervisor runs from. It only fits this repo's own source.
- `host`: the app's own jobs, which a plugin may not import: the watchdog, the schedule sweep, the
  flow tick, the brief, the fleet status, and the pull request status. A repo does not name it; the
  app always runs it.

- The supervisor reads it when it starts. After a change, restart it.
- A plugin you leave out schedules nothing. `npm run job <name>` refuses its jobs, and the
  message tells you to add the plugin to `PLUGINS` (the `plugins` list in the file).
- `npm run skills` follows the list, so `.claude/skills/` holds only the skills this checkout
  can run. `sync` removes the skills of a plugin you left out.
- `npm run crontab` ignores the list. It installs the watchdog, which every checkout needs.
- `ops` is always needed. Its `ops-lease-reap` job frees the lease (lock) of a run that died, and
  nothing else does that while the supervisor stays up. A list without `ops` is refused.
- A name that is not a plugin is refused when the supervisor starts. The message lists the
  names you can use.
- `git` only fits this repo's own source. In another repo, naming it is refused, and leaving
  `plugins` out leaves it out.
- One job can also fit only the engine: `nightly-sandcastle`, which lands a commit on the repo the
  engine works on. It is dropped wherever the checkout is a project's, and no `plugins` list turns
  it on there. The polish job runs wherever the `nightly` plugin runs.

---

## Credentials

Credentials live in `.doppelganger/creds/` in the repo folder. Git ignores `.doppelganger/` as a
whole. Each credential has a short name, so you can keep several accounts side by side. An older
setup kept them in `creds/` at the repo root: `config migrate` moves that folder (see "Settings").

    bin/runner.sh build pi                        # build the agent image
    bin/creds.sh add pi my-opencode               # make a model credential...
    bin/creds.sh login my-opencode                # ...and log in (type /login inside)
    bin/creds.sh add gh my-github                 # make a GitHub login...
    bin/creds.sh gh-login my-github               # ...and log in
    bin/creds.sh list                             # check what you have (never prints a secret)
    bin/runner.sh smoke pi my-opencode <provider/model>   # one tiny test call

For the codex runner, the steps are the same, with `codex` in place of `pi`:

    bin/runner.sh build codex                     # build the codex image; no release publishes it
    bin/creds.sh add codex my-openai              # make a codex credential...
    bin/creds.sh codex-login my-openai            # ...and log in: open the link, type the code
    bin/runner.sh smoke codex my-openai <model>   # one tiny test call

To log in with an API key, not a ChatGPT account, pipe the key in. The key is read from stdin and
never shown:

    printenv OPENAI_API_KEY | bin/creds.sh codex-login my-openai --api-key

In the container, the flow has no GitHub login of its own, so put the GitHub name in
`doppelganger.toml`: `gh = "my-github"` under `[exec]`. A row holds a name, never a token. The flow
uses it with every runner, and each pi or codex pass gets it mounted read-only.

### Keep the model list of a custom provider in step

A pi provider that is not built in (an OpenAI-compatible endpoint, such as `kenari` or `sumopod`) has a
models file in its credential folder: `.doppelganger/creds/pi/<name>/models.json`. It lists the models pi
may use there. The `ops-models-sync` job rewrites that list from the catalog at `exec.prices_url`, every
four hours. It matches a provider in the file to a provider of the catalog by its key.

- It changes only the `models` list of a provider the catalog also knows. The `baseUrl`, the `api`,
  the login file beside it and any other key stay. A key you added to one model (such as `compat`) stays too.
- It keeps a model that can call tools and has a context window and an output limit. An image or
  embedding model is left out.
- A model the catalog no longer lists is dropped. A catalog that cannot be read, or that lists no
  usable model for a provider, keeps the old list.
- A provider that is built in (such as `opencode-go`) has no models file, so pi keeps its own list.
- `[exec] models_sync_dry_run = 1` logs what would change and writes nothing. With no `prices_url`, the
  job does nothing.

### Hear when a cheaper provider sells a model you use

The `ops-price-watch` job runs once a day. It adds up the tokens your runs used in the last
`[exec] price_watch_days` days (7 by default), from the run logs in `.doppelganger/runs/`, plain or
gzipped. It prices them where they ran, and at every provider in the catalog at `exec.prices_url`
that sells the same model.

- Input, output, cache read and cache write each get their own price. Cache reads are most of an
  agent's tokens, so a cheap input price alone can be the dearer offer.
- An offer priced 0 is a subscription or a free tier, so it is never the cheaper offer.
- It posts through ntfy when one provider would save at least `[exec] price_watch_min_usd` dollars a
  week (2 by default). The same provider for the same model is posted again only after
  `[exec] price_watch_cooldown_days` (7 by default); a new cheapest provider is posted at once.
- `[exec] price_watch_dry_run = 1` prints the message and posts nothing. With no `prices_url`, the
  job does nothing.

### See how many tokens the runs use

Two viewers show the token use and cost of the agent runs, per day, model, provider and flow item.
Turn on one or both with a port under `[usage]` in `doppelganger.toml`, then start them:

    [usage]
    agentusage_port = 8787   # agentusage: a web dashboard
    tokscale_port = 7681     # Tokscale: a terminal UI, served as a web page
    bind = "127.0.0.1"       # the host address both listen on

    .doppelganger/dg usage up       # build the images on first use, then start what is on
    .doppelganger/dg usage down     # stop both

- The `ops-usage-export` job copies each run's usage into `.doppelganger/usage/pi` every 10 minutes,
  with no message text, and the viewers read that copy. With both ports 0 the job does nothing.
- agentusage has no login. Keep `bind` on `127.0.0.1` unless everyone on that network may see it.
- The Tokscale page runs a live program for whoever opens it. On any other address than
  `127.0.0.1`, `usage up` needs `tokscale_password` under `[usage]` in `doppelganger.secret.toml`;
  the login user is `dg`.
- Tokscale prices tokens with LiteLLM's price list; agentusage shows the cost pi recorded for each
  reply. So their totals can differ, but their token counts are the same.
- Only pi runs have usage in their logs. Codex runs are not counted.

### Choose who does the work

The flow has four roles. The **executor** writes the change and fixes what the review found
(`todo-change` and `todo-change-fix`). The **reviewer** checks it (`todo-change-review`). The **smart** role decides what the others cannot. The optional **cheap** role
fixes only the small `nit` findings of a passed review (`todo-change-nits`).

Each role is a list of providers, tried in order. Write one `[[exec.<role>]]` entry for each. An
entry holds:

- `runner`: `"claude"`, `"pi"`, `"codex"` or `"dsh"`. Required.
- `model`: for `pi`, the model as provider, a slash, then model (for example the one in the smoke test
  above). Required. For `codex`, an OpenAI model id such as `gpt-5-codex`, or the id a local server
  gives its model, such as `qwen3-coder:30b`. Required. It must be a full id: it holds a digit and is
  not a floating alias such as `latest`, `default` or `auto`. For `claude`, a pinned Claude model id
  such as `claude-opus-5`. Optional: left out, the pass runs on the job's own model. For `dsh`, the
  same shape as `pi`. Required. See "DeepSeek Harness" below.
- `creds`: for `pi`, `dsh` or `codex`, one credential name or a list of names, made with
  `bin/creds.sh add pi` or `bin/creds.sh add codex`. A `dsh` entry names pi credentials. Required, except for a `codex` entry with an
  `endpoint`, and for a `codex` entry while squad holds a codex account: its pass names none, and squad
  picks a free one with room. A shared `squad serve` needs a squad newer than 0.1.0-rc.8 for that.
  `claude` takes none: it uses the `claude` login of your own account, which the container shares.
- `endpoint`: `codex` only, optional. The base URL of an OpenAI-compatible server, such as a local
  model server. Left out, codex talks to OpenAI. See "Codex" below.

A `pi` entry may route instead of naming one provider. See "Cheapest provider first" below.

Any other key in an entry stops the supervisor at start, so a typo never passes in silence. Write the entries below
the plain `[exec]` keys: a key under an entry's header belongs to that entry.

With no entry, the executor, the reviewer and the smart role each run on claude with the job's own
model, and the cheap role is off. That is the default. Only claude needs no setting at all.

Only pi (the same for `reviewer` and `smart`):

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4.1-flash"
    creds  = "my-opencode"

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4-pro"
    creds  = ["account-a", "account-b"]

Codex (on OpenAI, then on a model server on this machine). The `endpoint` entry needs no credential:

    [[exec.reviewer]]
    runner = "codex"
    model  = "gpt-5-codex"
    creds  = "my-openai"

    [[exec.reviewer]]
    runner   = "codex"
    model    = "qwen3-coder:30b"
    endpoint = "http://host.docker.internal:11434/v1"

DeepSeek Harness, on the provider of a pi credential that holds an API key:

    [[exec.executor]]
    runner = "dsh"
    model  = "engy/deepseek-v4.1-flash-1017"
    creds  = "engy"

Mixed: the executor tries pi first and claude after it. The reviewer stays on claude:

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4-pro"
    creds  = "my-opencode"

    [[exec.executor]]
    runner = "claude"

Cheapest provider first. Several providers may sell the same model, each at its own price or on its
own plan. A routed `pi` entry names the lab model once and lists the providers with a credential for
each. It stands for one entry per provider that sells the model, cheapest first:

    [exec]
    prices_url = "https://models.dev/api.json"

    [[exec.executor]]
    runner = "pi"
    route  = "cheapest"
    model  = "deepseek/deepseek-v4-pro"

    [exec.executor.providers]
    alibaba-token-plan = "my-alibaba"
    opencode-go        = "my-opencode"
    sumopod            = "my-sumopod"

- `model` is the canonical id of the lab model: the `canonical_model_id` that the catalog gives each
  provider's model. The router finds each provider's own id for it. For example, sumopod sells the
  DeepSeek V4.1 Flash model as `deepseek-v4.1-flash:netra`, and the canonical id still finds it. If a
  provider has more than one id for the model, the cheaper one runs.
- The names in `providers` are the providers, each with one credential name or a list. A routed entry
  takes no `creds` of its own, and `route` has one value, `"cheapest"`. It must be a `pi` entry.
- `prices_url` is a models.dev style catalog: a JSON object of providers, each with `models`, their
  `cost` per million tokens and their `canonical_model_id`. The flow keeps a copy in
  `.doppelganger/state/` for six hours. If the catalog is down, it uses the old copy.
- The price is the cost of input counted three times plus the cost of output, divided by four. Equal
  prices keep the order you wrote. When a provider runs out of quota, the normal rules below move the
  pass to the next one. A plan that the catalog prices at 0 would always win, so give a flat plan a
  real price there.
- A provider that sells no model with that canonical id is skipped, and the log says so
  (`route-skipped`). A model with no canonical id in the catalog cannot be routed: name it in a plain
  entry instead. With no `prices_url`, or when no listed provider sells the model, the check at start reports
  a problem. There is no guessing from the model name.

When a pass fails, the flow moves down the list. One round keeps going, to a later credential or entry
each time and never back, until a pass works or nothing is left:

- A quota, auth or rate-limit refusal goes to the next credential of the same entry, and then to the
  next entry (on its first credential), whatever its runner. This holds for every role.
- For the executor, a `blocked` answer or an error from the model provider goes to the next entry.
- One round may mix these. Each step follows the kind of the latest failure, and goes on from the
  entry it is at.
- A pass that runs out of time (`idle` or `timeout`) or fails in a way the flow does not know does not
  go on. That is a slow or an unknown failure, so another model would not help.
- With nothing left, the step ends as it would with one entry.

A final message the flow cannot read (no marker line, or a bad outcome) is not a `blocked` answer, and
by itself it does not go to the next entry. A cold start on another provider costs more than asking
again. The same holds for a message that reads but claims work git does not show: `pr-opened` or
`pushed` with no new commit, or a rebase whose branch does not contain the base. A model can write
its tool calls as plain text, so none of them run, and still report the work as done. The executor
tries these steps in order:

1. A pi pass asks the same session once more: for the comment alone, or, for a false claim, for the
   missing work. The session lives in the shared session store under `.doppelganger/sessions/warm/`,
   which is also pi's session folder, so the provider's prompt cache still holds it.
2. Still unreadable, or the claim still false, the flow asks the decision model (below) two yes/no
   questions about the final message and the worktree: did the agent make real progress, and did it
   finish? For a false claim the model is told to judge the work by git, not by the message.
3. No real progress goes to the next entry. Real work that stopped early is told once, in the same
   session, to finish. Anything else, or no answer, parks the item on `blocked`.

The reviewer and the smart role are re-asked in their own session in the same way. A smart answer
is a closed choice that code reads: `resume` (run the parked step again), `replan` (go back to the
first step, with a reason) or `needs-human`. If the answer is still unreadable, the decision model
picks from that list. A weak pick, or no answer, parks the item on `needs-human`.
`[flow] no_decider = true` turns that last question off. The model sees the end of the answer and
nothing else.

### The decision model

Any job may ask Jev, TypeSafe's decision model, typed questions through the `decide` port (`kernel/ports/decide.ts`). It answers with
probabilities, and the job's own code makes the choice. The providers are a list, tried in order; the
next one is asked only after a failure:

```toml
[[jev.providers]]
provider = "zen"            # OpenCode Zen, free
model = "jev-1.13-free"

[[jev.providers]]
provider = "openrouter"     # paid
model = "typesafe/jev-1.13"
```

Each provider's key is a secret row in `doppelganger.secret.toml`: `zen_key` and `openrouter_key`
under `[jev]`. An entry whose provider has no key is skipped. A row naming an unknown provider, a
floating model id such as `~typesafe/jev-latest`, or an unknown key is dropped too, and logged as
`config-missing` at error, so a typo cannot pass for the deliberate no-provider setup. With no entry,
every ask gets no answer and each job takes its own safe default.

The comment on the PR lists every step in order, then the entry the pass ran on.

The cheap role is off while it has no entry. With one, a passed review that has `nit` findings gets one
cheap fix pass, then a fresh review. `[[exec.cheap]]` takes the same entries as the other roles.

### Codex

The codex runner has not been tested against a live model yet. Nobody has run a real pass on it, with
OpenAI or with a local server. The tests use a fake `docker`. Run the smoke test first, and watch the
log of the first real pass before you trust it.

What a codex pass does:

- It runs `codex exec` in the codex image, as your user, with no approval prompts and no sandbox of
  its own. The container is the sandbox. The skill text and the arguments go in on stdin.
- The answer of the pass is the last message codex writes to a file. A pass that ends with code 0 and
  no text in that file has failed.
- A codex agent reads the repo's `AGENTS.md`, as claude reads `CLAUDE.md`.
- The runner does not pass the job's effort setting. The model uses its own default.
- A credential is the `.doppelganger/creds/codex/<name>` folder, mounted as the codex home. A login that codex may
  refresh is mounted from the store itself, and the run holds a lock on it, so two passes on one
  login run one after the other. List more names to spread them. An API key is copied for each pass
  instead, with no lock.

Refusals are not told apart yet. There is no real sample of what codex says when a quota, a login or a
rate limit stops a pass, and a guess at that text would be wrong half the time. So every failed codex
pass counts as a provider error, whatever the cause: a non-zero exit, or an exit with no text. The
flow treats it as it treats any provider error. The executor goes on to the next entry, one after
another, and not to the next credential of the same entry. The other roles do not step on: the step
fails, and the flow tries it again on a later tick.

An `endpoint` entry:

- The server must speak the Responses API, at the endpoint plus `/responses`. That is the only
  protocol codex 0.162.1 can use with a server.
- The container shares the network of the host. The runner adds the name `host.docker.internal` for
  an endpoint that uses it; any other host name must resolve on its own.
- With `creds`, the key in that credential goes to the server, so make it with `--api-key`. A
  ChatGPT login there is refused, so its token never leaves OpenAI. With no `creds`, no key is sent.
- The URL holds no user name, password or query. A key never goes in the entry: it goes in the
  credential, and `doppelganger.toml` is committed.

### DeepSeek Harness

A `dsh` entry runs DeepSeek Harness, DeepSeek's own agent, in its headless mode: one task, the last
answer on stdout, and exit code 0 only when the task completed. dsh is a developer preview, and its
releases may break each other, so the image pins one version. No release publishes the dsh image.
Build it once on each machine that runs a dsh entry: `bin/runner.sh build dsh`.

What a dsh pass does:

- It runs `dsh --profile headless` in the dsh image, as your user, with no approval prompts and no
  sandbox of its own (`DSH_PERMISSION_MODE=danger-full-access`). The container is the sandbox. The
  skill text and the arguments go in on stdin.
- It uses a pi credential: the provider in its `.doppelganger/creds/pi/<name>/models.json` (the base URL, the API and the model
  list) and the API key in `.doppelganger/creds/pi/<name>/auth.json`. So one key serves pi and dsh, and ops-models-sync keeps the
  model list of both. The provider must speak `openai-completions`, `openai-responses` or
  `anthropic-messages`, and the model must be in its list. A credential that cannot serve the model
  counts as a refused login, so the flow goes on to the next credential or entry.
- The key goes into the container as an environment variable, never as an argument or in a file. The
  pass gets a fresh dsh home, so no saved setting, login or session of another pass reaches it.
- A dsh agent reads the repo's `AGENTS.md` and `CLAUDE.md`.
- The runner does not pass the job's effort setting. The model uses its own default.

Refusals are not told apart. A wrong key came back from a real gateway with the gateway's own words,
not a code the runner can trust, so every failed dsh pass counts as a provider error, as for codex.

Set the git author for the agents' commits once, inside the repo:

    git config --local user.name  "Your Name"
    git config --local user.email "you@example.com"

The repo may be public, so pick an email you are happy to show.

---

## Using the issue flow

### Write an issue

Write an issue on the tracker repo the way you would brief a new teammate: what is wrong, what you
expect, and how to check it is done. The `/todo-draft` skill in Claude Code drafts one in the right
shape for you.

Two things matter to the flow:

- **The `ready-for-agent` label.** The flow only takes up issues that carry it (the `entry_label` of
  the flow's tracker). The coder step files a finding it found while working an item of the same
  repo with this label too, so a finding re-enters the flow on its own. A finding for a repo whose
  flow's entry label is another lane is filed with no label: another writer owns that lane — the
  nightly-polish pass owns the night lane, for example — and the coder never files into a lane it
  does not own.
- **A `- Depends on:` line.** Write `- Depends on: #12, #15` when an issue needs other issues
  done first, or `- Depends on: none`. The flow waits until every issue on that line is closed,
  and it sends one ntfy message naming the open issues when nothing else is left to take, so a
  queue that waits does not look like an empty one.

### What the labels mean

The flow keeps the stage of an item in a `flow:` label. It sets the label itself: you add only
`ready-for-agent` (and `priority` to start an issue before the others).

| Label | Who acts next |
|---|---|
| `ready-for-agent` | The entry. An open issue with this label and no `flow:` label enters the flow. A finding the coder found while working an item of the same repo is filed with this label too. |
| `ready-for-night` | The night entry of this repo: the nightly-polish pass files one goal issue with it, and the `[flow.night]` flow works it. The nightly-polish pass is the only writer the coder knows of; a finding from a pass on a night issue is filed with no label. A repo's own config decides whether it has a night lane. |
| `priority` | **You.** You put it on an issue to have the flow start it before the others. The flow reads it only to order its backlog; nothing in the flow writes it or removes it. |
| `brief` | The engine's daily page. Read it, and tick what you did; only the morning run opens or closes it. |
| `pr-review` | The review of one pull request that no flow asked for. `watch-pr-review` files it and closes it when the pull request closes; no flow starts it. |
| `flow:<step>` | The step with that name works the item, for example `flow:coder` or `flow:github.merge`. |
| `flow:needs-answer` | The flow's answerer (a plugin, for example `smart`) looks at a parked step. |
| `flow:needs-human` | **You.** Read the question on the issue and reply in a comment. |
| `flow:done` | The flow finished the item. |

A repo may watch more than one flow, and their step names can share. The stage label names a step,
never a flow, so the flow of an item in one is the flow of the newest marker comment on the issue:
the other flow's sweep skips the item and runs no step on it. A stage label with no marker on the
issue yet (one a person added by hand) is open to whichever flow sweeps it; the first flow to take
it owns it from then on, by its own marker.

When a login from the flow's `humans` list replies on a `flow:needs-human` item, the flow sees the
comment within 5 minutes. The step's `asks` answerer reads the reply and picks the next move. When
`asks` is `"human"`, the parked step runs again. To give up on an issue, close it.

### How much runs at once

| Key | Default | Meaning |
|---|---|---|
| `[flow] in_flight` | 5 | The most started items that are not waiting for a person, across all flows. |
| `[flow] max` | 10 | The most items one flow tick takes per flow. Each takes at most one step. |
| `[flow] recheck_s` | 60 | Seconds a waiting item sleeps before its tracker is asked to wake it, when its step gave no time of its own. |
| `[flow] max_answers` | 2 | How many times the answerer may look at one parked item before it goes to a person. |
| `[agent] max_concurrent` | 3 | Agents alive at once on this machine, from any job. |
| `[lock] reenter_max_s` | 4500 | Seconds one program may keep entering a resource it already holds, queued waiter or not. 0 means the queue always wins. |
| `[run] idle_ms` | 600000 | An agent that prints nothing for this long (10 minutes) is stopped. A busy agent is never cut off. |

Ticks may overlap: `watch-flow` starts every 5 minutes and does not wait for the one before it. A
lease on each item keeps two ticks off the same item.

### Notifications

With `[ntfy] url` set, the flow sends a short message for the events a flow or a step lists in
`notify`. Without a list, you get these five:

- 🙋 `needs-human`: an item needs you,
- ✅ `done`: an item is done (with the link),
- 🏁 `idle`: no started item is left,
- ⏳ `blocked`: nothing is left to take, and the queue waits on the open issues named after it.
  The message repeats only when that set of issues changes,
- ⚠️ `error`: a tick failed for an item or a flow.

A step may also send its own results (`next`, `wait`, `fail`, `park`), and a flow `replan`. The
messages queue during a tick and go out once at its end, under the title `<topic> flow`, apart from
the log report's. A dry run sends none. `no_notify = true` under `[flow]` turns them all off.

### When something goes wrong

- **An agent stalls or crashes.** Its work is kept in its folder under `.worktrees/` and on its own
  branch. The next try continues from there. A step that keeps failing sends the item back to the
  first step with the reason, up to `max_replans` times, and then parks it.
- **"lease-held" in the log, and nothing moves.** A lock was left behind. Look at it with
  `npm run lease-clear -- flow-item`, and remove it with the command it prints.
- **A PR conflicts with its base, or CI fails on it.** `github.merge` merges a branch that is behind
  the base back into it and runs a check again once when it failed with no steps, and it waits on
  pending CI. A real failure ends the step with `fail`, and the flow goes back so that
  `coder` fixes the same pull requests.
- **The work already shipped in another pull request.** The coder answers `already-done` and names
  that pull request. The step takes it only when the pull request merged into the base and names the
  item in its title or body. It notes this on the issue, and the reviewer then checks the merged
  change against the issue, with the suite. A pass ends the step with that pull request, and the
  flow reaches `flow:done`. Asking for changes parks the item for you. The flow never closes the
  issue itself.
- **An agent found a problem it was not asked to fix.** `coder` files each one as a new
  `ready-for-agent` issue that depends on the source issue (up to 3 per pass). `no_findings = true`
  under `[change]` turns it off.
- **You want to look without changing anything.** Set `dry_run = true` under `[flow]`. The flow then
  only logs what it would do.

---

## Flows

A flow is a tracker and an ordered list of steps. The tracker holds the work items (GitHub issues
today). A step does one unit of work on an item, like `coder` (write the change and get it
reviewed) or `github.merge` (merge the pull requests that passed). The built-in steps are `coder`,
`github.deploy`, `github.merge`, `plan`, `qa` and `tester.test`. A plugin a repo attaches adds its
own to that list. The state of an item lives in
the tracker, as a label and as marker comments, so a restart loses nothing. Each tick runs at most
one step for each item.

Each flow is one `[flow.<name>]` table in `doppelganger.toml`:

```toml
[flow.engine]
tracker = "github"
repo = "hyhilman/doppelganger"
steps = ["coder", "github.merge"]
humans = ["hyhilman"]
asks = "smart"

[flow.engine.github.merge]
asks = "human"
```

`tracker` and `steps` are required. `humans` lists the logins whose reply frees a parked item.
`asks` says who looks first at a parked step: the name of an answerer, or `"human"` for a person.
A step table may set its own `asks`. A step may have its own table, like
`[flow.engine.coder]`. `doppelganger.example.toml` explains every key.

`github.merge` writes `Closes owner/repo#N` into the merge commit of a GitHub item, so GitHub closes the
issue when the merge reaches the repo's default branch. A merge into `dev` leaves it open until `dev`
reaches `main`.

The `coder` step (the plugin `coder`) reaches the code host only through a forge: a code host that a
plugin offers in its `forges` list. The `forge` option of its table names one, and the default is
`github`, which the `github` plugin offers. Boot refuses a flow whose `forge` names none that is
registered. Two limits stay for now. The agents that the step runs call `gh` themselves (the
skills read the pull request with `gh pr diff` and `gh pr view`), so every host still needs a
`gh` login in the agent's container. And the item key of a flow with no repo list must be a
`github:owner/repo#n` key.

A step ends with one of four results:

- `next`: the step is done. The item moves to the next step.
- `wait`: nothing to do now. The item is looked at again later.
- `fail`: the work failed. The flow goes back to the first step with the reason, up to `max_replans` times.
- `park`: the flow cannot go on. The step may list questions it needs answered. The flow's `asks`
  answerer looks first when one is set (the item sits at `flow:needs-answer`, and the answerer may
  look up to `max_answers` times). Then a person looks. When `asks` is `"human"`, or unset, the item
  goes straight to a person. A reply from a `humans` login goes back to the answerer, or, when
  `asks` is `"human"`, runs the parked step again.

Four jobs run a flow, one after the other in each 5-minute cycle: `source-flow` reads the tracker,
`triage-switch` routes the new items, `watch-ask` files the tickets a conversation asks for, and
`watch-flow` runs the steps.

**Dry run.** `[flow] dry_run` is on by default. A dry-run tick reads the tracker and logs the step
it would take for each item (the `flow-action` lines). It writes no label, status or comment, and it
runs no step. Set `FLOW_DRY_RUN=1` to force it for one run.

**Ticket asks.** A conversation can become tickets. A lane puts it on the route `ticket:<flow>`,
which exists for every flow whose tracker can file tickets (GitHub and Jira), while the `ask` plugin is
in the `plugins` list. Leave `ask` out and no ticket route exists, so a lane still pointing at one is
reported as an unknown route. The job `watch-ask`
takes each conversation, runs one agent pass that drafts 1 to `max_tickets` tickets (3 unless the
flow says more), and files them through the tracker. It records each ticket, so a re-run never files
twice. A ticket starts ready when every row of the conversation is from an author in the flow's `humans`
(matched by text, so list the name as the source shows it). Any other ticket waits: on GitHub it has
no entry label, and on Jira it has no `ready_label`, which the flow's `jql` must require. A person
starts it by adding that label. When the conversation's source can write back, the links go back into
that conversation as one message (Slack does, into the thread the ask came from); a source that cannot
leaves them in the `ask-filed` log line and the gap is named once. `watch-ask` runs every 5 minutes at :02, between `triage-switch` and `watch-flow`. It has `[ask] dry_run` (on by
default, so it files nothing until a person sets it to false), `[ask] max` and `ASK_NO_TICK`.

**Pull request reviews.** A pull request that no flow asked for still gets a review. `watch-pr-review`
runs three phases each tick: it reconciles every review item it holds against live GitHub, runs one
agent pass per pull request it has not seen and files one item for it, and runs the pass again on each
item whose pull request came back at a new head. The reviewed head against the live head is the whole
change signal, and a pull request that is closed or merged is final, so its item closes. The item is
the state: its body names the pull request, and each pass posts a marker comment with the head it read
and its verdict. A pull request that a flow opened is never reviewed here; the flow's coder step
reviews those. Two entries run the job, `watch-pr-review-tracked` every 10 minutes at :06 and
`watch-pr-review-discover` every 15 minutes at :13. They differ only in `[github] pr_discover`, the
broad poll, which is the one input that can hand the job pull requests nobody asked for. It has
`[github] pr_review_dry_run` (on by default, so it files nothing until a person sets it to false),
`[github] pr_review_max` and `[github] pr_review_flow`.

**The bug digest.** `watch-bug-digest` files one weekly issue of the unaddressed high and critical
findings the reviews left on the review items `watch-pr-review` keeps. A finding is reported once: every
tick reads the digest issues back from GitHub, open and closed, so a lost local file repeats no bug and
a retired report still dedups. A finding whose review item is declared standing is the exception, and
comes back in every digest. A cheap call groups findings that look like one bug; when it cannot
answer, each finding is its own bug. One repro pass then reads the real code at the reviewed commit and
gives the bug `armed`, `latent`, `refuted` or `unverified`; a message the job cannot read is
`unverified`, never `refuted`, and a parked pass still reports the bug. A bug's status is `shipped`
when its pull request merged, `ignored` when it closed unmerged, `unseen` while it is still open, and
`standing` when a person put the `bug-digest-standing` label on the review item and added the
`<!-- bug-digest-standing v=1 -->` marker to its body. A standing bug reads `main` instead of the
pull request head, and its findings stay in every week's digest until a person removes the label. It
has `[bug] digest_dry_run` (on by default, so it prints the digest and files
nothing) and `[bug] digest_min_severity`.

**Fixing what a review found.** `watch-pr-fix` fixes the reviewer findings on my own pull requests
that no flow owns. It reads the finding item another job files for the pull request: the item's title
names the pull request and its body carries one unchecked row per finding. A tick picks each item
with fixed gates and no model: the pull request is open and mine, no flow opened it, at least one row
is still unchecked, its kept worktree holds no work, my own last commit is older than the quiet
window, and neither the pull request's lifetime push cap nor the finding's own attempt cap is used
up. It then runs one pass in that worktree and pushes what the pass committed. It never writes the
item: the job that reads the reviewer threads ticks a row once its thread is resolved. The counters
sit in one meta blob, `pr_fix_pushes`, apart from that job's own table, and a blob the code cannot
read ends the tick, because an empty read would hand every pull request a whole new cap. The attempt
cap counts passes, not pushes: a pass is charged when it runs, so a finding a pass cannot fix stops
after that many runs instead of costing one every tick for ever.

The job that files the item is `watch-pr-feedback`, described just below. The row family it writes
and `watch-pr-fix` reads lives in one place, `plugins/github/botfindings.ts`, and
`plugins/github/botfindings.test.ts` pins the whole shape, so neither side can drift into a job that
silently finds nothing.

It has `[github] pr_fix_dry_run` (on by default, so it fixes nothing until a person sets it to
false), `[github] pr_fix_max`, `[github] pr_fix_flow`, `[github] pr_fix_quiet_min`,
`[github] pr_fix_push_cap` and `[github] pr_fix_attempt_cap`.

**Reviewer findings reach a person.** A reviewer bot's findings used to reach nobody. `watch-pr-feedback`
reads the open pull requests this account wrote, one child process per pull request and no model: the
child is one GraphQL read of the pull request's review threads, and the code parses each thread's
severity and writes the open ones as checkbox rows. One item per pull request holds them, titled
`[BOT owner/repo#<n>]`, and a row is ticked once its thread is resolved or a later look has settled it.
The change signal is the pull request's `updatedAt`, never the head SHA, because a bot may leave a
finding on a head that never moved. Each look keeps two moments: its own wall clock, which decides
whether a backlog row is newer than the last look, and the `updatedAt` its child read, which says
whether the pull request has moved since. The rotation is ordered by a third time, the moment a tick
last considered the pull request, written for every pull request it spent a slot on: a pull request
whose child fails or comes back cut is never stamped, and ordered by its stamp it would keep the front
of every tick. So the least recently considered pull request goes first, and the pull requests whose
reads fail take their turn after the rest. A backlog row about the pull request that is
newer than the last look buys one look, and the next look is newer than the row, and a
row later than the tick's own clock is ignored because no look can cover it. The stamp is written
after the pool and only for a pull request a child really answered, so a child killed at
`PR_FEEDBACK_CHILD_TIMEOUT_MS` costs the next tick a look and never its findings. Every read may be
cut: the open pull requests and the open items are walked page by page, and a read past its page
bound logs `page-cap` at `error` and files and stamps nothing. The job is `watch-pr-feedback`, and a schedule entry runs it every 20 minutes at :17. It has
`[github] pr_feedback_dry_run` (on by default), `[github] pr_feedback_max`, `[github] pr_feedback_pool`
and `[pr] feedback_child_timeout_ms`.

**Switching over from the old loop.** The flow replaced `todo-loop` and `watch-human-reply`, which
are gone. Before you deploy a release that has no `todo-loop`:

1. Let `todo-loop` finish its items in flight, or hand them to a person. Wait until nothing is
   mid-step.
2. List what is left, with read-only `gh` commands (replace `<owner>/<name>` with the tracker repo):

        gh pr list --repo <owner>/<name> --state open --json number,title,headRefName --jq '.[] | select(.headRefName | startswith("exec/issue-"))'
        gh issue list --repo <owner>/<name> --state open --label agent-review
        gh issue list --repo <owner>/<name> --state open --label agent-fix
        gh issue list --repo <owner>/<name> --state open --label needs-smart
        gh issue list --repo <owner>/<name> --state open --label needs-human
        gh pr list --repo <owner>/<name> --state open --label agent-review
        gh pr list --repo <owner>/<name> --state open --label agent-fix
        gh pr list --repo <owner>/<name> --state open --label needs-smart
        gh pr list --repo <owner>/<name> --state open --label needs-human

3. Clear the settings the loop read from `doppelganger.secret.toml` (and from the environment, if you
   set any there). The supervisor refuses to start on a key that is not a setting. These keys are gone:
   `[exec]` `tracker`, `base`, `dry_run`, `no_merge`, `no_comment`,
   `no_notify`, `max`, `walk_alert`, `slots`, `refill_min`, `recheck_ms`, `max_rounds`,
   `max_escalations`, `max_findings`, `no_findings`, `no_heal`, `no_jev` and
   `humans`. The flow table takes their place: `repo`, `humans` and the step options (`base`,
   `max_rounds`, `test_cmd`, `strip_ids`) now live under `[flow.<name>]`. `distinct_reviewer` moved to
   another table: the flow reads `[github] distinct_reviewer` as `[exec] distinct_reviewer` was
   read. If you had it on, set it there, or the merge stops being gated.
4. Then deploy. Set `[flow] dry_run = false` to let the flow work.

The flow does not adopt the items `todo-loop` left in flight. A pull request on an `exec/issue-*`
branch, or an item with `agent-review`, `agent-fix`, `needs-smart` or `needs-human`, carries labels the
flow does not read, so nobody moves it. Finish or close each one by hand. To let the flow take an
issue instead, close its old pull request, remove the old stage labels and add `ready-for-agent`.

### See every item and its pull requests

`npm run job watch-pr-status` prints one page of every item a flow has started, with the stage it is
at, how long that stage has held it, and the live state of each pull request the item points at: open,
merged, closed, or unknown when the code host could not be read. It reads the trackers and the code
host and writes nothing, so it is safe to run at any time and it holds no setting. A pull request's
state is read when the page is made, never from the marker the flow left, so the page shows what the
code host says now.

A person runs it by hand, and it has no schedule. A flow with nothing started is named on the page,
so an empty flow and a forgotten one read alike. A store that cannot be read is printed with the
reason, next to the items that could be read.

---

## Lanes

The triage switch gives every new backlog item one route. Code rules go first: a bot's post, a flow's
own rows, and a source you pin. What the rules leave, the switch asks the decision model about, one
conversation at a time. A conversation is judged once it has been quiet for `[switch] quiet_m` minutes.

A lane is one answer the model may give. Each `[lane.<name>]` table has an `intent` (the criteria the
model judges), an `output`, and optionally `sources` (the sources it is offered for) and `pin` (a source
whose rows always take the lane, with no model). The model only picks a lane name from the list. The code
writes the route of that lane's output:

| output | route written |
|---|---|
| `none` | `fyi` (settled, nothing to do) |
| `human` | `human-action` (a person pulls it in the brief) |
| `human:now` | `incident` (claimed and pinged at once) |
| `flow:<name>` | `flow:<name>` (that flow's own route; the lane may cover that flow's source only) |
| `ticket:<flow>` | `ticket:<flow>` |

A conversation is `unknown` when no lane is offered for its source, the model gives no answer, or its pick
is below `[lane] min`. `[lane] no_decider = true` sends nothing to the model. `doppelganger.example.toml`
explains every key, and a bad lane stops the supervisor, `npm run job` and `config check` at start.
`triage-probe` asks the same question over live rows and writes nothing.

A row also reaches `human-action` from a person's own hand, with no source and no model:
`BACKLOG_ADD_TEXT='…' npm run job backlog-add` writes one todo for the person who wrote it, and the same
text twice is the same row.

The `backlog-dlq` job writes the dead-letter queue to `.doppelganger/dlq.md` and posts the same
report through ntfy, on the topic of the log report. A schedule entry runs it once a day at 07:20 UTC,
and `npm run job backlog-dlq` runs it by hand. The report has one line per dead row, with the step
that gave up and how many times it tried. A person ticks a box on that page, and the next run revives
the row. `npm run dlq -- revive <id>` is the other door.
A page the run cannot read is not overwritten: the run logs the file and the fault, revives nothing,
and still reports the queue, so a tick is never lost to a read this run could not do.

---

## The daily brief

`backlog-brief` keeps one open page in a flow's tracker and works it in three runs. The morning run
settles the boxes you ticked on yesterday's page, claims up to `BRIEF_MAX` of the quiet asks, files
today's page and closes yesterday's. The progress and eod runs only rewrite the open page, so you
read one page and not a thread of updates; with no page open they write nothing. Only the morning run
opens or closes a page.

The page lists, in order, the asks that look like one ask, the open asks and the dead letters (tick one
to settle it), what the end-of-day pass closed, what was read and cleared, your open pull
requests, and a fold naming what the cap held back. A box you tick stays ticked: the progress and eod
rewrites keep a ticked ask under the open asks and never spend the cap on it, so the next morning
settles it. `BRIEF_FLOW` names the flow whose tracker holds the page. `BRIEF_DRY_RUN` is on by
default: a run prints the page it would file and writes nothing.

---

## The health digest

`backlog-health` is the inventory digest, built with no agent and writing nothing:
`npm run job backlog-health` prints one page. A source that stops does not look like a queue growing —
nothing arrives, so nothing waits, and the backlog reads like a quiet week. The digest is what tells
the two apart.

It says how many rows remain, the age of the oldest untriaged ask, how many rows still waiting the
switch could not place (`unknown`), how big the dead-letter queue is, when the switch last ticked, and
the counts per route. The size line also names how much was ever written, as `lifetime`, because a row
that has settled still counts there and nothing has to act on it; every number that says what waits now
comes from the open rows only. Below that it lists the stuck routes in two groups: those a watcher
drains, naming the job, and those nothing drains, which is the worse of the two. Then how long ago each
source last reported, which accounts a quota breaker has left dark, and the dead letters themselves.

A route is stuck when a `routed` row sat untouched for `[backlog] health_stuck_h` hours (6 unless you
change it). A dark account is a breach when it has stayed dark for `[backlog] dark_h` hours (24 unless
you change it); the row says how long it has been dark and when it re-probes.
`BACKLOG_HEALTH_DRY_RUN` is on by default: the digest is printed and nothing is sent. Set it to 0 and
the same page goes out through ntfy.

## The web site

One site can show every supervisor you run. Each supervisor is a **workspace**. The site is read-only: no
page and no route changes a supervisor, a flow, an item or an account. It has two parts, and each runs where
its data is:

- `doppelganger api` is the **instance API** of one supervisor. It reads that supervisor's own data and
  answers only a caller that sends a bearer token (a secret string that proves who the caller is). It
  speaks plain HTTP.
- `doppelganger web` is the **hub**: the web app, the sign-in (OIDC, the login standard of an identity
  server) and a read-only view of every workspace, all on one origin. It reads each supervisor through that
  supervisor's instance API with the token you gave it, and no token ever reaches the browser.

### Start api and web

From the image, `dg` starts each as a service of the repo's compose file:

    .doppelganger/dg api up
    .doppelganger/dg web up
    .doppelganger/dg api status      # where it answers, and the container
    .doppelganger/dg web down

Each service sits behind a compose profile of its own name, so `dg up` never starts it. `dg down` stops
them with everything else. `web` runs in the network of `api`, so `127.0.0.1` inside the hub is the instance
API beside it, and a workspace at `http://127.0.0.1:<api port>` works. `dg web up` starts `api` too, and the
`api` service publishes both ports. Stopping `api` (`dg api down`) cuts the hub off, so start `web` again
after it. Compose publishes the port on `127.0.0.1` and on no other address, so only this
machine reaches it. The ports are `port` under `[api]` (7321 unless you change it) and `port` under `[web]`
(7320). `dg` reads both from the settings files, the secret file first, and it refuses to start the service
when the value is not a port from 1 to 65535. The `bind` key of each is for a run outside a container: the
container listens on all of its own addresses so that the published port can reach it, and the publish
line is the guard. From an engine checkout or an installed package, run `npx doppelganger api` and
`npx doppelganger web` under a process manager instead (in a checkout, `npm run web:build` makes the web app
first).

The hub needs these keys, under `[web]` in `doppelganger.toml`:

| key | what it is |
|---|---|
| `url` | the public origin of the hub, an https address with no path |
| `oidc_issuer` | the OIDC issuer URL of your identity server |
| `oidc_client_id` | the client id of the hub at that server |
| `oidc_group` | optional: a group the ID token must hold; unset lets in any verified email |
| `workspaces` | one `[[web.workspaces]]` table per supervisor (see below) |
| `port`, `bind` | where the hub listens |

These three are secrets, so they go in `doppelganger.secret.toml` under `[web]`, or in the environment:
`oidc_client_secret` (optional, for a confidential client), `session_key` (at least 32 bytes of random
text, such as the output of `openssl rand -base64 48`) and `workspace_tokens`. `doppelganger config check`
stops on a key that no setting explains and on a secret in the shared file. The instance API takes `bind`
and `port` under `[api]`.

### Add a workspace

A workspace is one `[[web.workspaces]]` table in the hub's `doppelganger.toml`. `name` is a lowercase
letter, then lowercase letters, digits and dashes. `url` is the base URL of that supervisor's instance
API, and it must be https unless its host is the loopback. `squad_web` is optional: the https origin of the
squad web of that supervisor, which the page shows in a frame.

    [[web.workspaces]]
    name = "shop"
    url = "http://127.0.0.1:7321"

The token of each workspace goes in `doppelganger.secret.toml`, as `name=token` pairs split by spaces:

    [web]
    workspace_tokens = "shop=<token> lab=<token>"

A workspace on another machine is reached over https, through a tailnet or a private tunnel. Never over
plain HTTP on the open network.

The hub runs on the host network, so `127.0.0.1` in it is this machine's loopback. A workspace whose API
listens there, in a container that publishes to the loopback or as a process outside docker, is
`http://127.0.0.1:<its port>`.

A workspace on the same machine, in another repo, is reached over the docker network `doppelganger-hub`.
`dg api up` makes it when it is missing and joins it, and there the instance API of each repo has the name
`dg-api-<instance>` (the `instance` of that repo's `doppelganger.toml`). The hub accepts plain http to such
a name, and to no other name but the loopback:

    [[web.workspaces]]
    name = "squad"
    url = "http://dg-api-squad-77a298h:7341"

The port is the one that repo's API listens on (`[api] port`), not one this machine publishes.

### Mint and revoke a token

Run this on the supervisor whose workspace you add, with one hub name per hub:

    .doppelganger/dg token add hub

It prints the token once, on its own line. The store keeps only a hash, so a lost token cannot be shown
again: revoke it and add a new one. Copy the token to `workspace_tokens` of the hub. `dg token list` lists
the hubs with their times and state, and `dg token revoke hub` ends a token. From a checkout or a package
the same commands are `npx doppelganger token add <hub>`, `npx doppelganger token revoke <hub>` and
`npx doppelganger token list`.

### The tunnel rule

The public tunnel maps only the hub, doppelganger.hilman.dev, and squad web,
squad.doppelganger.hilman.dev. Never map an instance API, `squad serve` or the supervisor.

`dg squad-web up` starts `squad web` on the squad home that `squad serve` shares, as the compose service
`squad-web`. It listens on `127.0.0.1` at port 20140, and the tunnel maps squad.doppelganger.hilman.dev to
that. When another squad web on the machine holds 20140, set `DG_SQUAD_WEB_PORT` to another port in the
environment of `dg`, and point the tunnel there. Set `DG_SQUAD_HOME` to the squad home (an absolute path of a folder that exists, with no space or
colon in it) in the environment of `dg`. It refuses to start without it, so it never runs on an empty
home. Squad's own sign-in settings come from the same environment: `SQUAD_OIDC_ISSUER`,
`SQUAD_OIDC_CLIENT_ID` and, if you want them, `SQUAD_OIDC_GROUP` and `SQUAD_OIDC_ADMIN_GROUP` (the group
whose members see every account, also the ones with no owner). Compose holds no secret: squad reads its
client secret and session key from its own secret file in its home.

Squad web starts containers for "Sign in with Claude", the codex device login and the **Test** button. It
uses the rootless docker socket that the passes use, and a temp folder `dg` makes at
`.doppelganger/squad-web-tmp` (squad refuses a mount inside its own home). The login images
(`squad-claude`, `squad-codex`) must be on that rootless daemon: build them there with `squad image build`,
or copy them with `docker save ... | DOCKER_HOST=unix://$XDG_RUNTIME_DIR/docker.sock docker load`.

    DG_SQUAD_HOME=~/.squad SQUAD_OIDC_ISSUER=<issuer> SQUAD_OIDC_CLIENT_ID=<id> .doppelganger/dg squad-web up

The page can be framed only by the hub's own site.

---

## Safety switches

Every job that writes to the outside world has switches, so you can try it without risk. Each is a
setting in `doppelganger.toml` (`dry_run = true` under `[flow]`). To try one for a single run, set
the variable instead: it beats the file, and nothing in the file changes.

- `FLOW_DRY_RUN=1`: do nothing for real, only log.
- `FLOW_MAX=0`: a free test that reads the trackers but takes no item.
- `FLOW_MAX=1`: lets one real item through per flow.
- `<NAME>_DB=/tmp/x.db`: point a job's database at a throwaway file.

Every other surface that writes carries the same four kinds of switch, spelled per surface here.
A _dry run_ in the table is the surface's `_DRY_RUN` switch, a **cap** its `_MAX` switch, a
_shadow_ a `_NO_*` switch. All of them are free, except where the row says one runs a real agent
pass: `NIGHTLY_SANDCASTLE_DRY_RUN runs one real agent pass`, so it costs money and writes nothing.

| Writes                            | dry run                          | cap                      | shadow                     | database     |
|-----------------------------------|----------------------------------|--------------------------|----------------------------|--------------|
| the flow tick, every flow          | `FLOW_DRY_RUN`                  | `FLOW_MAX`               | `FLOW_NO_TICK`, `FLOW_NO_NOTIFY`, `FLOW_NO_MERGE` | `FLOW_DB`    |
| the ask tick, the ticket routes    | `ASK_DRY_RUN`                   | `ASK_MAX`                | `ASK_NO_TICK`              | `ASK_DB`     |
| pi and codex passes, through squad | —                               | —                        | `RUNNER_NO_SQUAD` (the old pi and codex runners) | — |
| corpus-checklist, the checklist    | `CORPUS_CHECKLIST_DRY_RUN`      | `CORPUS_CHECKLIST_MAX`   | —                          | `CORPUS_DB`  |
| corpus-lint, the reference corpus  | `CORPUS_LINT_DRY_RUN`           | —                        | `CORPUS_NO_LINT_PUSH`      | —            |
| the nightly pass, the sandcastle   | `NIGHTLY_SANDCASTLE_DRY_RUN` (one real agent pass) | `NIGHTLY_SANDCASTLE_MAX` | `NIGHTLY_NO_SANDCASTLE`, `NIGHTLY_NO_SANDCASTLE_MERGE` | `NIGHTLY_DB` |
| the nightly pass, the polish       | `NIGHTLY_POLISH_DRY_RUN`        | `NIGHTLY_POLISH_MAX`     | `NIGHTLY_NO_POLISH`        | `NIGHTLY_DB` |
| ops-log-report, the report post    | `LOG_REPORT_DRY_RUN`            | —                        | —                          | `LOG_DB` |
| ops-retention, the sweep           | `RETENTION_DRY_RUN`             | —                        | —                          | `LEASE_DB`, `LOG_DB` |
| ops-lease-reap, the dead-lease sweep | `CLAIM_REAP_DRY_RUN`          | `CLAIM_REAP_MAX`         | —                          | `LEASE_DB` |
| ops-session-reap, the warm sessions (dead owners, clean ones idle for `SESSION_REAP_IDLE_DAYS`, and the old pi session folder) | `SESSION_REAP_DRY_RUN`         | `SESSION_REAP_MAX`       | `SESSION_REAP_NO_IDLE` (the idle sweep) | — |
| ops-fleet-status, the fleet report | `OPS_FLEET_STATUS_DRY_RUN`      | —                        | —                          | — |
| ops-hub-health, the hub tool count | `OPS_HUB_HEALTH_DRY_RUN`        | `OPS_HUB_HEALTH_MAX`     | —                          | — |
| ops-models-sync, the models.json   | `EXEC_MODELS_SYNC_DRY_RUN`      | —                        | —                          | — |
| ops-price-watch, the price post    | `EXEC_PRICE_WATCH_DRY_RUN`      | —                        | —                          | — |
| ops-reset-branches                 | `RESET_DRY_RUN`                 | —                        | —                          | —            |
| ensure-env-worktrees               | `ENV_WORKTREE_DRY_RUN`          | —                        | —                          | —            |
| reset-env-to-main's weekly re-cut  | `RECUT_DRY_RUN`                 | —                        | `GIT_NO_RECUT`             | —            |
| ops-self-sync                      | `SELF_SYNC_DRY_RUN`             | —                        | `SELF_SYNC_NO_PULL`        | —            |
| corpus-refresh, the service pull   | `CORPUS_REFRESH_DRY_RUN`        | `CORPUS_REFRESH_MAX`, `CORPUS_REFRESH_RUNBOOK_MAX` | —                          | `CORPUS_DB`  |
| retro-weekly, the weekly retro     | `RETRO_DRY_RUN`                 | `RETRO_LANE_LIMIT`       | —                          | `RETRO_DB`   |
| the GitHub source sweep            | `GITHUB_DRY_RUN`                | `GITHUB_ACTOR_MAX`, `GITHUB_REVIEW_BOT_MAX` | `GITHUB_NO_COMMENT` | `GITHUB_DB`  |
| ops-release-phase, the phase gate  | `GITHUB_PHASE_DRY_RUN`          | `GITHUB_PHASE_MAX`, `GITHUB_PHASE_PLACE_MAX` | `GITHUB_NO_PHASE` | `GITHUB_DB`  |
| watch-pr-review, the review items  | `GITHUB_PR_REVIEW_DRY_RUN`      | `GITHUB_PR_REVIEW_MAX`   | —                          | —            |
| watch-bug-digest, the weekly digest | `BUG_DIGEST_DRY_RUN`            | —                        | —                          | —            |
| watch-pr-fix, a review's findings  | `GITHUB_PR_FIX_DRY_RUN`         | `GITHUB_PR_FIX_MAX`      | —                          | —            |
| watch-pr-feedback, the bot findings | `GITHUB_PR_FEEDBACK_DRY_RUN`  | `GITHUB_PR_FEEDBACK_MAX` | —                          | `GITHUB_DB`  |
| the Jira source sweep              | `JIRA_DRY_RUN`                  | —                        | —                          | `JIRA_DB`    |
| the Slack source sweep             | `SLACK_FETCH_DRY_RUN`           | —                        | —                          | `SLACK_DB`    |
| the Notion source sweep            | `NOTION_DRY_RUN`                | `NOTION_AUTHOR_CACHE_MAX` | —                         | `NOTION_DB`  |
| the triage switch, the tick        | `SWITCH_DRY_RUN`                | `SWITCH_DLQ_MAX`, `BACKLOG_SWITCH_STALE_M` | `PIPELINE_NO_SWITCH`, `LANE_NO_DECIDER` | — |
| backlog-brief, the read routes     | `BRIEF_DRY_RUN`                 | `BRIEF_MAX`, `BRIEF_READ_MAX` | —                      | `BACKLOG_DB` |
| backlog-add, the hand-written todo | `BACKLOG_ADD_DRY_RUN`           | —                        | —                          | `BACKLOG_DB` |
| backlog-dlq, the report page       | `BACKLOG_DLQ_DRY_RUN`            | —                        | —                          | `BACKLOG_DB` |
| backlog-health, the digest         | `BACKLOG_HEALTH_DRY_RUN`        | —                        | —                          | `BACKLOG_DB`, `QUOTA_DB` |
| the coder step's side findings     | —                               | —                        | `CHANGE_NO_FINDINGS`, `CODER_NO_DECIDER` | — |
| the tester and smart answerers     | —                               | —                        | `TESTER_NO_DECIDER`, `SMART_NO_DECIDER` | — |
| the stale answerer                 | —                               | —                        | `STALE_NO_SELF_SETTLE`     | — |
| the audit store: flow events, agent passes, job runs | — | — | `AUDIT_NO_RECORD` | `AUDIT_DB` |
| the watchdog                       | `WATCHDOG_DRY_RUN`              | —                        | `WATCHDOG_NO_NOTIFY`       | —            |
| `crontab` sync                     | `CRONTAB_DRY_RUN`               | —                        | —                          | —            |
| `skills` sync                      | `SKILLS_DRY_RUN`                | —                        | —                          | —            |
| `lease-clear`                      | `LEASE_CLEAR_DRY_RUN`           | —                        | —                          | —            |
| `quota-clear`                      | `QUOTA_CLEAR_DRY_RUN`           | —                        | —                          | —            |
| `dlq`                              | `DLQ_DRY_RUN`                   | —                        | —                          | —            |
| `init`                             | `INIT_DRY_RUN`                  | —                        | —                          | —            |
| `config migrate`                   | `CONFIG_DRY_RUN`                | —                        | —                          | —            |
| `token`                            | `TOKEN_DRY_RUN`                 | —                        | —                          | —            |
| the instance API (`api`)           | —                               | —                        | `API_NO_SERVE`             | `API_DB`     |
| the web hub (`web`)                | —                               | —                        | `WEB_NO_SERVE`             | —            |

The table also leaves out a surface: the release tool (`cli/release.ts`, the engine of "Releases"
below) is not in the package, so it is not a job here and holds no setting in the files. Its
switches are set only in the environment, spelled as their rows' why:

`RELEASE_DRY_RUN=1`: `publish and bump print the files they would write, and publish also the tag it would make and push, the tarball it would pack and the release it would create, and do none of it; they still read the tags`

---

## Releases

CI makes three kinds of build, one branch each: `dev`, then `rc`, then `main`. Only `rc` builds by
itself; the other two are a button. A build is made only after `npm test` passed on that same commit.

- **dev**, from the `dev` branch, when a person starts it: Actions, release, **Run workflow**, on `dev`.
  Version `0.2.0-dev.gabc1234`: `g` and the short hash of the commit. The `g` keeps the version valid when a hash is all digits. It has no GitHub release. The one git tag `dev-build` moves to it, and the images get the tag `dev`.
- **release candidate**, from the `rc` branch: version `0.1.0-rc.1`, then `0.1.0-rc.2`. It is a GitHub
  pre-release with its own tag, and the images get the tag `rc`.
- **stable**, from `main`: version `0.1.0`. It is a normal GitHub release. A person starts it: Actions, release, **Run workflow**, on `main`. It refuses unless the tests passed on that commit.

Work moves `dev`, then `rc`, then `main`. When a phase is finished (see "Release phases"), the
`ops-release-phase` job starts the `release-candidates` workflow, which moves `rc` forward to the newest `dev`
commit whose tests passed, so one phase of work is one release candidate. It does nothing when `dev`
has nothing new, and stops when `rc` holds a commit `dev` does not (merge `rc` into `dev` first). Its
**Run workflow** button does the same by hand. Every build has:

- a git tag, `v` and the version (`v0.1.0-rc.1`), or the moving tag `dev-build`. The tag sits on a commit
  made for the build: the pushed commit plus a `package.json` that holds the exact version and the
  names of the images. Only the tag is pushed. The branches do not move, so CI does not start again;
- the package, as a tarball on the GitHub release (not for a dev build);
- two images on ghcr.io: the supervisor and the pi runner. They carry the version as their tag. A
  dev build also moves the tag `dev`, a release candidate moves `rc`, and a stable release moves
  `latest`. The supervisor image carries the engine of that version, which is what "Run it from the
  image" runs. No release publishes the codex image.

How a release is made, and how its version is picked: see "Releases" in `CONTRIBUTING.md`.

### Release phases

A phase is a GitHub milestone titled like a version, `v0.3.0` or `0.3.0`. The `ops-release-phase`
job (github plugin, every hour at :45) cuts a release candidate per finished phase, not per night:

- The current phase is the open milestone with the lowest version. Other milestone titles are ignored.
- A new flow issue joins the **next** phase, the second-lowest open version milestone. The job makes
  that milestone, one minor step up, when it is missing. A flow issue carries an entry label from
  `[github] phase_labels` or a `flow:` stage label; any other issue is yours to place. So a phase
  that is current keeps a fixed set and can finish, and new findings ship in the one after.
- The phase is finished when every issue in it is closed or carries `flow:done`. `flow:done` means
  merged, waiting for a release. Pull requests in the milestone do not count.
- A finished phase starts the workflow named by `[github] phase_workflow`. The job stores the set of
  issues and the start time. On a later night with the same set, it reads the workflow's runs since
  that time:
  - a success: nothing to do;
  - a run still going, or none listed yet: wait;
  - a failed run: start the workflow again.

  A done issue that joins the phase later makes one more candidate.
- Once a stable release tagged `v<version>` exists, the job comments "Released in v…" on each done
  issue of the phase and closes it, then closes the milestone. The next milestone becomes the phase.
- An open issue that is not done was not in that release. The job names it in a warn line and keeps
  the milestone open, so a person can move the issue to the next phase.
- After each stable release the job raises the base by itself. It reads the `version` in `dev`'s
  `package.json`, and when that version has a stable release it starts the workflow named by
  `[github] phase_base_workflow` (`raise-base`) with the lowest open milestone above it, once per
  version. That milestone must be one step up: patch, minor or major. The workflow sets the version in
  `package.json`, opens a pull request to `dev` and starts the `test` workflow on its branch. A later
  run merges the pull request when the `test` run on its head commit succeeded. A failed run warns and
  merges nothing, and a milestone that is not one step up warns and starts nothing: a person picks the
  version then.
- `bump` is still the manual way to raise the base (see `CONTRIBUTING.md`). A project that leaves
  `[github] phase_base_workflow` unset raises no base.

The candidate is whatever the workflow takes, so it can carry merged work of the next phase too. The
job does nothing until `[github] phase_repo` names a repo, and `phase_dry_run` is on until you turn it
off. The base step also waits for `[github] phase_base_workflow`; unset, it makes no gh call.
`GITHUB_NO_PHASE=1` stops it.

### Log in once

The repo and the images are private. Installing the package uses your git login. Pulling an image
needs a login to ghcr.io. Run this once on each machine, with your GitHub user name and a token
that has the `read:packages` scope:

    docker login ghcr.io

### Install a version

To run from the image instead of installing anything, see "Run it from the image". To install the package:

    npm install -D github:hyhilman/doppelganger#v0.1.0-dev.3
    npx doppelganger init

Use `#v0.1.0` for a stable version, `#v0.1.0-rc.1` for a release candidate. Or install from the tarball of the release:

    gh release download v0.1.0-rc.1 --repo hyhilman/doppelganger --pattern '*.tgz'
    npm install -D ./doppelganger-0.1.0-rc.1.tgz

Both report the exact version in their `package.json`. A branch install (`#dev`, `#main`) is not a
release: no image was built for it, so `init` writes a compose file that builds the image on your
machine.

`init` writes a compose file that names the supervisor image of that exact version. Its next steps
tell you to pull that image and the pi image of the same version. Pull the pi image on the host
yourself. The container starts pi passes through the host's docker and has no ghcr.io login of its
own. With `image` under `[runner.pi]` unset, a release runs the pi image of its own version. An engine checkout
runs its local build, as before. No release publishes a codex image: on each machine that runs a codex
entry, build it with `bin/runner.sh build codex`.

### Upgrade

1. Install the new version, as above.
2. Delete `.doppelganger/compose.yml` and run `npx doppelganger init` again. It writes the compose
   file with the new image and leaves your settings files alone. Or edit the version in the image line by hand.
3. Pull the new images: the supervisor with compose, and the pi image with the `docker pull` line
   that `init` prints:

        docker compose -f .doppelganger/compose.yml pull

4. Restart: `docker compose -f .doppelganger/compose.yml up -d`.
