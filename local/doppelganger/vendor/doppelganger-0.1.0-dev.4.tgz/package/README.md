# doppelganger

**AI coding agents that work through your GitHub issues while you are away.**

You write issues. doppelganger picks them up one by one, lets an agent write the code, opens a pull
request, has a second agent review it, merges it when the review and CI pass, closes the issue,
and sends a note to your phone. When an agent gets stuck, it asks you a question on the issue and
waits for your reply.

It also runs other small jobs on a schedule (nightly clean-ups, log reports, health checks).

> Status: early and personal. It runs this repo's own backlog today. Expect rough edges.

---

## How it works

     you write an issue  ──►  label: ready-for-agent
                                   │
                                   ▼
            ┌─────────── the loop (every 5 minutes) ───────────┐
            │  1. executor agent writes the code               │
            │     in its own folder                            │
            │     (.worktrees/<name>/<name>-issue-<n>)         │
            │  2. opens a pull request                         │
            │  3. reviewer agent checks it ──► changes? ──► fix│
            │  4. CI green + review pass  ──►  merge           │
            │  5. close the issue, ping your phone             │
            └──────────────────────────────────────────────────┘
                                   │
                 stuck? ──►  label: needs-human  ──►  you reply on the issue

The main pieces:

- **Supervisor**: one long-running process. It starts each job at the time the schedule says. The
  schedule lives in `host/schedule.ts`.
- **Jobs**: small programs grouped into plugins under `plugins/`. The issue loop is `todo-loop`
  in `plugins/todo/`.
- **Agents**: each role of the loop runs on the providers you choose, in order: the pi coding agent or
  OpenAI's codex agent, each in a throwaway Docker container with a model and credentials you give it,
  or claude. A pi or codex agent never sees your home folder.
- **Leases**: small locks in a local database, so two runs never work the same issue at once.

---

## What you need

- A Linux machine that stays on.
- Node.js, except when you run from the image (see the next section). The exact version is in `.nvmrc`.
- Docker. Rootless Docker is recommended: the agents then never get root on your machine.
- The GitHub CLI (`gh`), logged in to an account that can push to the repo.
- An account with a model provider (for example OpenCode Go, or Claude).
- Optional: an [ntfy](https://ntfy.sh) server or topic, for phone notifications.

---

## Run it from the image

This is the way with the least on your machine: **only Docker**. There is no engine checkout and no
package install. Every release publishes a supervisor image that carries the engine, and `version` in the
repo's committed `doppelganger.toml` picks the image. Each repo can run a different version.

Which way to pick:

- **The image** (this section): a repo that needs nothing from the engine but its built-in plugins. Any
  repo works, Node project or not.
- **The package** ("Install it in your repo"): the repo has its own plugins in `doppelganger.config.ts`, or
  you want the engine version in the repo's lockfile. The image runs the built-in plugins only.
- **The engine checkout** ("Set it up" and "Run it on your other repos"): you work on the engine, or one
  checkout should serve many repos. This repo runs itself this way.

The images are private, so log in once on each machine, with a GitHub token that has the `read:packages`
scope. Then, in the repo, run `init` from the image of the version you want:

    docker login ghcr.io
    cd ~/code/api
    docker run --rm -it -u "$(id -u):$(id -g)" -v "$PWD:$PWD" -w "$PWD" \
      ghcr.io/hyhilman/doppelganger-supervisor:0.1.0-dev.3 init

`dg` starts the supervisor on the docker daemon your `docker` command uses by default, as `bin/fleet.sh`
does, and only the passes use the rootless daemon. It refuses to start the supervisor on a rootless
daemon, because there the container's user maps to another user on the machine and cannot read the
secret file or the credentials. If your shell sets `DOCKER_HOST` to the rootless socket, unset it for `dg`.

`init` runs inside the repo, so it needs no path. The image name is the one a release prints (see
"Releases"). Add `-e INIT_DRY_RUN=1` first to see what it would do without writing anything. It writes:

- `doppelganger.toml`, with `version = "0.1.0-dev.3"` (the version of the image that ran) and the
  settings `init` can derive. Commit it. It holds no secret;
- `doppelganger.secret.toml`, mode 600, for your tokens. Git ignores it;
- three files under `.doppelganger/`: the compose file, the `dg` launcher and the watchdog. They hold
  no edit of yours, so `init` writes them again every run, and each has a header that says so. Git
  ignores the folder.

`init` never overwrites `doppelganger.toml` or `doppelganger.secret.toml`. When one exists, it lists the
lines to add. It makes no tracker labels, because a one-shot container has no `gh` login. The next steps
it prints are these, and every command after the first is the `dg` launcher in the repo:

    .doppelganger/dg creds add gh my-github        # a GitHub login, kept in this repo's .doppelganger/creds/
    .doppelganger/dg creds gh-login my-github
    .doppelganger/dg labels                        # the tracker labels, with that login
    .doppelganger/dg up                            # pull the image, start the supervisor (a dry run at first)
    .doppelganger/dg logs -f
    .doppelganger/dg cron install                  # the watchdog entry (and the update entry of a channel) on this machine's crontab

Before `labels`, set `gh = "my-github"` and `humans` under `[exec]` in `doppelganger.toml`, and `test_cmd`
to the repo's test command. The agents run on claude by default. To run on pi or codex, add the entries
that "Choose who does the work" describes, and make their logins with `dg creds add pi <name>` and
`dg creds login <name>`. The pi image goes with the release: the engine in the supervisor image names
it, and `dg up` pulls it on the machine, because the container has no registry login of its own (see
"The pi image" below). To pull it by hand, for example before the first `dg up`:

    docker pull ghcr.io/hyhilman/doppelganger-pi:0.1.0-dev.3

No release publishes the codex image. Build it once on each machine that runs a codex entry:
`.doppelganger/dg runner build codex`.

### Upgrade

Set `version` in `doppelganger.toml` to the new release, commit it, and run `.doppelganger/dg up`. `dg`
sees that the pin is not the version it was made from. It asks the pinned image to write the launcher,
the compose file and the watchdog again (`init --refresh`), starts over with the new launcher, pulls the
new image and restarts the container. `dg up` pulls the new pi image as well.

A supervisor or a job whose engine is not the pinned version refuses to start, and the message names
both versions. That also stops a stale container from running after you changed `version`.

`version` takes one of two things: an exact version such as `0.1.0-dev.3`, or the channel `dev`. Any
other word (`latest`, `0.1`) is refused, and the message names the two forms. Only `dev` is a channel for
now.

### The pi image

A release runs the pi image published for its own version, unless `image` under `[runner.pi]` is set.
The supervisor container has no registry login, so the pi image has to be on the host. `dg up` and
`dg update` do that: they ask the pulled supervisor image which pi image it expects, with `docker run
--rm <image> version --images`, and pull that one on the host with `docker pull`, into the rootless
daemon where the supervisor starts the pi passes. They do it for an exact pin and for a channel. A pull that fails stops `dg up` before it starts the supervisor, and
refuses `dg update` (see below).

- They pull it always, whether or not the repo has a pi entry. A repo without pi entries pays one small
  pull.
- When `image` under `[runner.pi]` is set, in `doppelganger.secret.toml` or `doppelganger.toml`, the image
  is yours: `dg` neither asks nor pulls, and you keep it on the host yourself.
- They pull a reference only of the form `<registry>/<name>:<exact version>`. An image that names no
  such reference (a local build that no release stamped) gets no pull.
- `DG_NO_PULL=1` skips this pull too.

### Follow the dev channel

With `version = "dev"` a repo runs the newest dev build, with no edit in the repo. Every push to the
`dev` branch makes a dev build and moves the image tag `dev` to it (see "Releases"), and this repo
follows that tag. **The channel is meant for the engine's own repo.** A push to `dev` reaches the
running supervisor within the hour, so a bad push reaches it too. **Every other repo should pin an
exact version**, and change it on purpose: a commit, then `dg up`.

How it works:

- The image tag is the pin itself, so `dg` and the compose file use the tag `dev`, and `version = "dev"`
  makes no check of the engine's version at boot. The supervisor and `npm run job` log one info line
  (`version-pin-channel`) with the engine's own version and the channel.
- The tag stays `dev` while the image behind it changes, so after a pull `dg up` asks the pulled image
  which release it holds, with `docker run --rm <image> version`. No supervisor starts for this. When
  that release is not the one the launcher was made from, the pulled image writes the launcher, the
  compose file and the watchdog again, as for a new exact pin.
- `dg cron install` adds a second line to the managed crontab block: `dg update` at minute 8 of every
  hour. The watchdog runs at minutes 3, 18, 33 and 48. An exact pin installs no update line, and
  `dg cron install` takes the line out again when the pin stops being `dev`. Until then `dg cron check`
  reports drift.

`dg update` is the step the crontab line runs. You can run it by hand. It does this:

1. It pulls the pinned image. If the image the container runs is the one it pulled, it logs `up to
   date` and stops. The same holds for an exact pin, where the pull rarely brings anything new. (A
   current image pulls no pi image.)
2. It stops if the last update of this very image did not start (see the rollback below).
3. **The check before the switch.** The new image runs once, with `docker run --rm` (not compose), on this
   repo with a read-only mount: `config check`. It makes the checks of the settings that the supervisor
   makes at boot: the plugin choice, the version pin, unknown keys, keys that must not be in the shared
   file, a token in it, and each plugin's own check, such as the todo plugin's role entries. If the
   check fails, the old image stays. `dg` logs `update refused: config` and one line for each reason,
   with the key and the path and never a value, and exits 0, so the next hour asks again. Fix the
   settings, or wait for a newer image.
4. **The pi image.** It pulls the pi image of the new release on the host (see "The pi image"). If that
   pull fails, the supervisor would fail every pi pass after the switch, so the old image stays: `dg`
   logs `update refused: pi image` with the reference and the reason, and exits 0. The next hour tries
   again. This comes before the wait, next to the check above.
5. It waits for the supervisor to be idle: no job process is alive and no agent run is in flight. It
   reads `.doppelganger/supervisor.status.json`, which the supervisor writes every minute and when a job
   starts, with `grep` and `cut`. The host needs no node and no jq. It looks every 30 seconds, for up to 10
   minutes. If the supervisor never goes idle, it logs `update waits: busy` and exits 0, so the next
   hour tries again. A status file that is missing or older than 5 minutes, or a container that is not
   running, counts as idle, because nothing is running. A status file that cannot be read counts as
   busy.
6. When idle, it writes the launcher files again from the new image if its release differs, and runs
   `docker compose up -d`, which recreates the container on the new image. It logs the old and the new
   release.
7. **The rollback.** Before it recreates the container, `dg` keeps the old image under the local tag
   `dg-rollback`. After the switch it waits up to 5 minutes for a heartbeat that is newer than the
   switch. 5 minutes is the age at which the watchdog calls a heartbeat stale, and a normal boot writes
   the first heartbeat within seconds. If none comes, or `up -d` fails, `dg` writes the id of the new
   image to `.doppelganger/update.bad`, has the old image write the launcher files back when the
   release changed, recreates the container on `dg-rollback`, logs `update rolled back` with the old
   and the new release, and exits 1. Later runs skip an image with the recorded id. A different (newer)
   image clears the file. Delete the file by hand to try the same image again.

Every event is one logfmt line in `.doppelganger/logs/dg-update.log`, in the shape of the repo's other logs.
Error lines there reach the log report like any other. A lock file, `.doppelganger/update.lock`, keeps
two updates from running at once.

These variables of the launcher are not settings of the engine, like `DG_IMAGE` and `DG_NO_PULL`
(which `update` honours too):

- `DG_UPDATE_DRY_RUN=1` pulls (both images), runs the check, looks once at the supervisor, prints what it
  would do, and changes nothing: no switch, no log file, no lock, no kept image.
- `DG_UPDATE_POLL_S` (30), `DG_UPDATE_IDLE_WAIT_S` (600) and `DG_UPDATE_BOOT_WAIT_S` (300) are the
  seconds it looks, waits for idle, and waits for the first heartbeat. The defaults are right for real
  use. A test sets them small.

### The commands

`dg` runs the commands that need the engine in a throwaway container of the pinned image, so they work
whether or not the supervisor is up.

    .doppelganger/dg up              pull the pinned image and its pi image, then start the supervisor
    .doppelganger/dg down            stop and remove it
    .doppelganger/dg restart         restart the container
    .doppelganger/dg logs -f         follow its output
    .doppelganger/dg status          the facts dg starts it with, and what is running
    .doppelganger/dg pull            pull the pinned image
    .doppelganger/dg update          pull the pinned image and its pi image; if it is new, wait for an idle supervisor and switch to it
    .doppelganger/dg job <name>      run one job by hand
    .doppelganger/dg list            the jobs this repo runs
    .doppelganger/dg dlq             list or revive the rows that died
    .doppelganger/dg lease-clear     free a lease by hand
    .doppelganger/dg labels          create the tracker labels with the repo's own gh login
    .doppelganger/dg creds ...       the credential store (bin/creds.sh, run in the image)
    .doppelganger/dg runner ...      the runner images (bin/runner.sh, run in the image)
    .doppelganger/dg cron install    put the watchdog, and for the channel dev the hourly update, on this machine's crontab
    .doppelganger/dg cron check      say whether those entries match this version
    .doppelganger/dg watchdog        run the watchdog once, now
    .doppelganger/dg help            this list

`cron install` uses the image's own crontab tool on a copy of your crontab, and installs the copy with the
machine's `crontab` program. Every line outside the managed block stays as it was. It stops with a message
when the machine has no `crontab`. The entry runs `.doppelganger/watchdog.sh`, a copy of `host/watchdog.sh`
that needs bash and system tools only: it does not look for node or the engine on the machine, because
they are in the image. It still checks the heartbeat and the delivery stamps, and sends the ntfy message.

### What the image does not run

- **Your own plugins.** The image runs the built-in plugins only. A plugin of your own imports the
  package, which this way does not put in the repo. A repo with a `doppelganger.config.ts` should
  install the package instead.
- **`nightly` and `git`.** They only fit the engine's own source (see "What a repo does not run").
- **Anything of the older ways.** The engine is not mounted from the machine, so `bin/fleet.sh` and
  `npm run` commands are not part of this way.

Two things you may see in the repo that you did not make. `.doppelganger/engine/<version>/` holds a copy
of the skills for the pi runner, made once per version: the pi container is started by your machine's
docker daemon, which cannot see the engine inside the image. And `.doppelganger/crontab.work` exists for
a moment while `cron install` runs.

For a build that is not in a registry, `DG_IMAGE=<name>` runs another image name, and `DG_NO_PULL=1` skips
the pull.

---

## Set it up

This part is the engine checkout way: the repo that holds the engine runs itself. For a repo that has
no engine, see "Run it from the image", "Install it in your repo" and "Run it on your other repos".

### 1. Settings

Settings live in two files in the repo folder. Nothing reads a `.env` file.

- `doppelganger.toml` is committed. It holds the settings your team shares, and no secret.
- `doppelganger.secret.toml` is not committed (git ignores it). It holds tokens, and any value that
  differs on this machine, such as `cmd` under `[crontab]`.

Make both from the examples. The secret file holds tokens, so keep it private (mode 600):

    cp doppelganger.example.toml doppelganger.toml
    cp doppelganger.secret.example.toml doppelganger.secret.toml
    chmod 600 doppelganger.secret.toml

Open them. Every setting has a one-line comment that explains it. The examples show each default as
a commented-out line: remove the `#` only to change one. A small `doppelganger.toml` is enough:

    plugins = ["todo", "ops"]

    [exec]
    tracker = "acme/widgets"
    base = "main"
    humans = "your-github-login"
    test_cmd = "npm test"
    dry_run = true

    [ntfy]
    url = "https://ntfy.example.com"

    [crontab]
    cmd = "/usr/bin/crontab"

Put the token in `doppelganger.secret.toml`:

    [ntfy]
    token = "tk_your_token"

A secret setting is set in the environment or in `doppelganger.secret.toml`, never in
`doppelganger.toml`. There are two: `NTFY_TOKEN` and `JIRA_API_TOKEN`. The supervisor and `npm run
job` refuse to start when `doppelganger.toml` sets one, or holds any value that looks like a token
(a GitHub token, an API key, a long run of letters and digits). The message names the file and the
key, never the value. `doppelganger.secret.example.toml` lists the secret settings. A setting that is
not secret may sit in either file, and the secret file wins when both set it. The one thing the
secret file cannot hold is a `[[...]]` list of tables, such as `[[exec.executor]]`: those stay in
`doppelganger.toml`.

A key is the name of its setting, in lower case. The first word is the table, and the rest is the key,
so `EXEC_TRACKER` is `tracker` under `[exec]`, and `PLUGINS` is `plugins`, with no table. A key in
either file that is not a setting stops the supervisor and `npm run job` when they start, so a typo
never passes in silence.

For one run, an environment variable beats both files. `EXEC_DRY_RUN=1 npm run job todo-loop` runs the
loop once in dry run, whatever the files say. The order is: the environment, then
`doppelganger.secret.toml`, then `doppelganger.toml`, then the default. Each key that the environment
and a file both set is logged at start as `settings-override`, with the key and never its value. Two
settings come from the environment only: `ENGINE_ROOT` (the repo to work on) and `DOPPELGANGER_CONFIG`
(the path of `doppelganger.toml`, or `none` for no file; the secret file is the one in the same
folder).

Only settings go in these files. A variable that is not a setting, such as a login token for another
tool, is not read from them. In the container, set it under `environment:` in the compose file. On the
host, set it in your shell.

This repo (the engine) commits no `doppelganger.toml` of its own. When you run the engine from its own
checkout, your copy shows up in `git status` as a new file. The self-sync and nightly jobs skip a
checkout that is not clean, so hide it: add the line `/doppelganger.toml` to your clone's exclude file
(`git rev-parse --git-path info/exclude` prints where it is).

#### Upgrade from the older layout

Older versions kept every setting in a `.env`, and later in one gitignored `doppelganger.toml` that
held the tokens too, with the logins in `creds/` at the repo root. Stop the supervisor, then run
`npm run config -- migrate` (add `CONFIG_DRY_RUN=1` first to see what it would do). It does up to
three jobs, and never prints a value:

- With a `.env`, it writes `doppelganger.secret.toml` (the secret settings, mode 600) and
  `doppelganger.toml` (all others, mode 644) from it, and leaves `.env` as it is. It names every key
  it could not carry over. Check the new files, then delete `.env`. It never overwrites either file.
  The old runner row and the models and credentials of each role become `[[exec.<role>]]` entries:
  when the runner was `pi`, each model is one entry (see "Credentials"). Under claude those rows were
  never read, so they make no entry.
- With no `.env`, it looks at a `doppelganger.toml` from before the secret file, and moves its secret
  rows to a new `doppelganger.secret.toml`. It cuts out only the lines of those rows, so the comments
  stay. When it cannot cut a row (written as a dotted key, an inline table, or over many lines), it
  writes the file again from its content, and says that the comments are lost. It stops, and tells
  you which keys to move, when `doppelganger.secret.toml` already exists.
- It moves `creds/` to `.doppelganger/creds/` with one rename. It stops, naming both folders, when
  both exist.

It then tells you what to change in `.gitignore`: add `doppelganger.secret.toml` and `.doppelganger/`,
and remove `doppelganger.toml`, so the file can be committed.

The issue loop reads its settings from the same file, under `[exec]`. A checkout runs one loop on one
tracker, so each setting is one row. The ones to set first:

| Key | What it is |
|---|---|
| `[exec] tracker` | The GitHub repo (owner, a slash, then name) whose issues the loop works. No default: the loop does not run until you set it. |
| `[exec] base` | The branch the loop branches from and merges into. Default `main`. |
| `[exec] humans` | GitHub logins whose reply releases a `needs-human` item. |
| `[exec] test_cmd` | The shell command that runs the repo's whole test suite, for example `npm test`. No default. The agents run it before they commit. Unset, an agent looks for the command in the repo's own docs. |
| `[exec] strip_ids` | `false` (default). `true` drops planning IDs (a short prefix, a dash and a number) from the PR title and commit subject the loop writes. Set it only for a repo whose AGENTS.md bans them. |
| `[[exec.executor]]` | One entry per provider, tried in order. The same for `[[exec.reviewer]]`, `[[exec.smart]]` and `[[exec.cheap]]`. With none, each role runs on claude with the job's own model (see "Credentials"). |
| `[exec] dry_run` | `true` (default) only logs. Set `false` to go live. |
| `[ntfy] url` | Your ntfy server, if you want phone notifications. Its `token` goes in `doppelganger.secret.toml`. |

A flag is `true` or `false` in the file (`1` and `0` also work, and are what the environment uses).

The loop is named after the checkout folder (or the top-level `instance` setting). That name is in its
lease keys, its worktree folders and its log lines, so two checkouts on one machine never share them.

`[crontab] cmd` and `[exec] tracker` have no default and are always needed. `[crontab] cmd` is the
full path to your `crontab` binary (run `which crontab`); it differs per machine, so it may go in
`doppelganger.secret.toml`. `[exec] test_cmd` has no default either, but
the loop runs without it. The role entries have no default either, and the loop runs without them: a
role with no entry runs on claude.

#### Choose which plugins run

By default a checkout runs every plugin under `plugins/`, and every plugin the repo attaches (see
"Install it in your repo"). To run only some, name them in `doppelganger.toml`:

    plugins = ["todo", "ops"]

The names are the folder names under `plugins/`, and the names of the plugins a repo attaches. Leave
`plugins` out to run them all. Once you set it, it is the whole list: a plugin it does not name is off.

- The supervisor reads it when it starts. After a change, restart it.
- A plugin you leave out schedules nothing. `npm run job <name>` refuses its jobs, and the
  message tells you to add the plugin to `PLUGINS` (the `plugins` list in the file).
- `npm run skills` follows the list, so `.claude/skills/` holds only the skills this checkout
  can run. `sync` removes the skills of a plugin you left out.
- `npm run crontab` ignores the list. It installs the watchdog, which every checkout needs.
- `ops` is always needed. Its `ops-lease-reap` job frees the lease (lock) of a run that died, and
  nothing else does that while the supervisor stays up. A list without `ops` is refused.
- A name that is not a plugin is refused when the supervisor starts. The message lists the
  names you can use.
- `nightly` and `git` only fit this repo's own source. In another repo (see "Run it on your other
  repos"), naming either is refused, and leaving `plugins` out leaves them out.

### 2. Credentials

Credentials live in `.doppelganger/creds/` in the repo folder. Git ignores `.doppelganger/` as a
whole. Each credential has a short name, so you can keep several accounts side by side. An older
setup kept them in `creds/` at the repo root: `config migrate` moves that folder (see "Settings").

    bin/runner.sh build pi                        # build the agent image
    bin/creds.sh add pi my-opencode               # make a model credential...
    bin/creds.sh login my-opencode                # ...and log in (type /login inside)
    bin/creds.sh add gh my-github                 # make a GitHub login...
    bin/creds.sh gh-login my-github               # ...and log in
    bin/creds.sh list                             # check what you have (never prints a secret)
    bin/runner.sh smoke pi my-opencode <provider/model>   # one tiny test call

For the codex runner, the steps are the same, with `codex` in place of `pi`:

    bin/runner.sh build codex                     # build the codex image; no release publishes it
    bin/creds.sh add codex my-openai              # make a codex credential...
    bin/creds.sh codex-login my-openai            # ...and log in: open the link, type the code
    bin/runner.sh smoke codex my-openai <model>   # one tiny test call

To log in with an API key, not a ChatGPT account, pipe the key in. The key is read from stdin and
never shown:

    printenv OPENAI_API_KEY | bin/creds.sh codex-login my-openai --api-key

In the container, the loop has no GitHub login of its own, so put the GitHub name in
`doppelganger.toml`: `gh = "my-github"` under `[exec]`. A row holds a name, never a token. The loop
uses it with every runner, and each pi or codex pass gets it mounted read-only.

#### Choose who does the work

The loop has four roles. The **executor** writes the change (`todo-exec` and `todo-fix`). The
**reviewer** checks it. The **smart** role decides what the others cannot. The optional **cheap** role
fixes only the small `nit` findings of a passed review.

Each role is a list of providers, tried in order. Write one `[[exec.<role>]]` entry for each. An
entry holds:

- `runner`: `"claude"`, `"pi"` or `"codex"`. Required.
- `model`: for `pi`, the model as provider, a slash, then model (for example the one in the smoke test
  above). Required. For `codex`, an OpenAI model id such as `gpt-5-codex`, or the id a local server
  gives its model, such as `qwen3-coder:30b`. Required. It must be a full id: it holds a digit and is
  not a floating alias such as `latest`, `default` or `auto`. For `claude`, a pinned Claude model id
  such as `claude-opus-5`. Optional: left out, the pass runs on the job's own model.
- `creds`: for `pi` or `codex`, one credential name or a list of names, made with
  `bin/creds.sh add pi` or `bin/creds.sh add codex`. Required, except for a `codex` entry with an
  `endpoint`. `claude` takes none: it uses the `claude` login of your own account, which the
  container shares.
- `endpoint`: `codex` only, optional. The base URL of an OpenAI-compatible server, such as a local
  model server. Left out, codex talks to OpenAI. See "Codex" below.

Any other key in an entry stops the loop, so a typo never passes in silence. Write the entries below
the plain `[exec]` keys: a key under an entry's header belongs to that entry.

With no entry, the executor, the reviewer and the smart role each run on claude with the job's own
model, and the cheap role is off. That is the default. Only claude needs no setting at all.

Only pi (the same for `reviewer` and `smart`):

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4.1-flash"
    creds  = "my-opencode"

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4-pro"
    creds  = ["account-a", "account-b"]

Codex (on OpenAI, then on a model server on this machine). The `endpoint` entry needs no credential:

    [[exec.reviewer]]
    runner = "codex"
    model  = "gpt-5-codex"
    creds  = "my-openai"

    [[exec.reviewer]]
    runner   = "codex"
    model    = "qwen3-coder:30b"
    endpoint = "http://host.docker.internal:11434/v1"

Mixed: the executor tries pi first and claude after it. The reviewer stays on claude:

    [[exec.executor]]
    runner = "pi"
    model  = "opencode-go/deepseek-v4-pro"
    creds  = "my-opencode"

    [[exec.executor]]
    runner = "claude"

When a pass fails, the loop moves down the list. One round keeps going, to a later credential or entry
each time and never back, until a pass works or nothing is left:

- A quota, auth or rate-limit refusal goes to the next credential of the same entry, and then to the
  next entry (on its first credential), whatever its runner. This holds for every role.
- For the executor, a `blocked` answer or an error from the model provider goes to the next entry.
- One round may mix these. Each step follows the kind of the latest failure, and goes on from the
  entry it is at.
- A pass that runs out of time (`idle` or `timeout`) or fails in a way the loop does not know does not
  go on. That is a slow or an unknown failure, so another model would not help.
- With nothing left, the step ends as it would with one entry.

The comment on the PR lists every step in order, then the entry the pass ran on.

The cheap role is off while it has no entry. With one, a passed review that has `nit` findings gets one
cheap fix pass, then a fresh review. `[[exec.cheap]]` takes the same entries as the other roles.

#### Codex

The codex runner has not been tested against a live model yet. Nobody has run a real pass on it, with
OpenAI or with a local server. The tests use a fake `docker`. Run the smoke test first, and watch the
log of the first real pass before you trust it.

What a codex pass does:

- It runs `codex exec` in the codex image, as your user, with no approval prompts and no sandbox of
  its own. The container is the sandbox. The skill text and the arguments go in on stdin.
- The answer of the pass is the last message codex writes to a file. A pass that ends with code 0 and
  no text in that file has failed.
- A codex agent reads the repo's `AGENTS.md`, as claude reads `CLAUDE.md`.
- The runner does not pass the job's effort setting. The model uses its own default.
- A credential is the `.doppelganger/creds/codex/<name>` folder, mounted as the codex home. A login that codex may
  refresh is mounted from the store itself, and the run holds a lock on it, so two passes on one
  login run one after the other. List more names to spread them. An API key is copied for each pass
  instead, with no lock.

Refusals are not told apart yet. There is no real sample of what codex says when a quota, a login or a
rate limit stops a pass, and a guess at that text would be wrong half the time. So every failed codex
pass counts as a provider error, whatever the cause: a non-zero exit, or an exit with no text. The
loop treats it as it treats any provider error. The executor goes on to the next entry, one after
another, and not to the next credential of the same entry. The other roles do not step on: the step
fails, and the loop tries it again on a later tick.

An `endpoint` entry:

- The server must speak the Responses API, at the endpoint plus `/responses`. That is the only
  protocol codex 0.162.1 can use with a server.
- The container shares the network of the host. The runner adds the name `host.docker.internal` for
  an endpoint that uses it; any other host name must resolve on its own.
- With `creds`, the key in that credential goes to the server, so make it with `--api-key`. A
  ChatGPT login there is refused, so its token never leaves OpenAI. With no `creds`, no key is sent.
- The URL holds no user name, password or query. A key never goes in the entry: it goes in the
  credential, and `doppelganger.toml` is committed.

Set the git author for the agents' commits once, inside the repo:

    git config --local user.name  "Your Name"
    git config --local user.email "you@example.com"

The repo may be public, so pick an email you are happy to show.

### 3. Start it

The supported way is the container. Everything goes through `bin/fleet.sh`:

    bin/fleet.sh build      # build the supervisor image
    bin/fleet.sh up         # start it; it restarts on its own until you stop it
    bin/fleet.sh status     # what it found on this machine, and what is running
    bin/fleet.sh logs -f    # follow its output

`bin/fleet.sh down` stops it, and `bin/fleet.sh shell` opens a shell inside it. The image bakes in no
user: it runs as your own user and home. The agent CLI version is pinned in the `Dockerfile`;
`bin/fleet.sh build --claude <version>` builds another one.

### 4. The watchdog

The watchdog checks every 15 minutes that the supervisor is still alive. It runs from your
machine's own crontab, not inside the container, so it still works when the container is down.

    npm run crontab check     # show what would change
    npm run crontab sync      # install it

It installs exactly one entry, `ops-watchdog`. Before the first sync, `check` says
`no managed block installed` and exits 1. That only means "not installed yet".

---

## Using the issue loop

### Write an issue

Write an issue on the tracker repo the way you would brief a new teammate: what is wrong, what you
expect, and how to check it is done. The `/todo-draft` skill in Claude Code drafts one in the right
shape for you.

Two things matter to the loop:

- **The `ready-for-agent` label.** The loop only touches issues that carry it.
- **A `- Depends on:` line.** Write `- Depends on: #12, #15` when an issue needs other issues
  done first, or `- Depends on: none`. The loop waits until every issue on that line is closed.

### What the labels mean

| Label | Who acts next |
|---|---|
| `ready-for-agent` | The executor agent writes the code. |
| `agent-review` | The reviewer agent checks the pull request. |
| `agent-fix` | The executor fixes what the review found. |
| `needs-smart` | A stronger model looks at a hard question. |
| `needs-human` | **You.** Read the question on the issue and reply in a comment. |
| `priority` | Not a stage. Add it next to the others, and the loop works this issue before the rest, once its `Depends on:` issues are closed. |

When you reply on a `needs-human` issue, the loop sees your comment within 5 minutes and carries
on. To give up on an issue, close it.

### How much runs at once

| Key | Default | Meaning |
|---|---|---|
| `[exec] slots` | 3 | Issues the loop works at the same time. |
| `[agent] max_concurrent` | 3 | Agents alive at once on this machine, from any job. |
| `[exec] max` | 1 | Steps one issue may take per round. 6 lets an issue go from code to merge in one go. |
| `[exec] refill_min` | 60 | Minutes a round keeps starting new issues. After that it drains; a later round may join and fill the free slots, so new settings apply sooner. |
| `[exec] recheck_ms` | 120000 | Milliseconds (2 minutes) a step that said `waiting` waits before the same round looks at the issue again. 0 means look again as soon as a slot frees. |
| `[lock] reenter_max_s` | 4500 | Seconds one program may keep entering a gated resource past a queued waiter. 0 means the queue always wins. |
| `[run] idle_ms` | 600000 | An agent that prints nothing for this long (10 minutes) is stopped. A busy agent is never cut off. |

Issues labelled `priority` go first. After them, open pull requests are always reviewed and merged
before new issues start.

### Notifications

With `[ntfy] url` set, you get a short message when:

- ✅ an issue is done (with the pull request link),
- 🙋 an issue needs you,
- ⏸ the queue is stuck behind issues that need you,
- 🏁 the queue is empty,
- ⚠️ the loop hit an error.

`no_notify = true` under `[exec]` turns them off.

### When something goes wrong

- **An agent stalls or crashes.** Its work is kept: committed, pushed to its own
  branch on GitHub, and left in its folder under `.worktrees/`. The next try continues from there. After a few
  stalls the issue moves to `needs-human`.
- **"lease-held" in the log, and nothing moves.** A lock was left behind. Look at it with
  `npm run lease-clear -- exec`, and remove it with the command the log prints.
- **A PR conflicts with its base.** The loop sends it to `agent-fix`, and the fixer rebases it. A
  PR that was parked on `needs-human` only for conflicts is not picked up by itself: remove
  `needs-human` and add `agent-review`. The loop then sees the conflict and starts the rebase.
- **CI fails on a PR that passed review.** The loop heals it before it asks you. If the branch is
  behind its base, GitHub merges the base in and CI runs again, since the base may already hold
  the fix. If CI still fails, the fixer gets the failing log lines and fixes the cause. After
  `[exec] max_rounds` fix rounds, the stronger model decides, and asks you only when it must.
  `no_heal = true` under `[exec]` parks a red PR on `needs-human` at once.
- **An agent found a problem it was not asked to fix.** The loop files each one as a new
  `ready-for-agent` issue that depends on the source issue (`[exec] max_findings` per pass,
  `no_findings = true` under `[exec]` turns it off).
- **You want to look without changing anything.** Set `dry_run = true` under `[exec]`. The loop then
  only logs what it would do.

---

## Day to day

| I want to… | Do this |
|---|---|
| See what is running | `bin/fleet.sh status` |
| Follow the loop | `bin/fleet.sh logs -f`, or the files in `.doppelganger/logs/` |
| See the schedule | `node host/supervisor.ts --list` |
| Change a setting | Edit `doppelganger.toml` (or `doppelganger.secret.toml` for a token). The next round reads it; no restart needed. `plugins` and the `[supervisor]` settings are the exception: restart. |
| Load new code | `bin/fleet.sh down` then `bin/fleet.sh up` |
| Run one job by hand | `npm run job <name>` |

Never run two supervisors for one checkout (for example, the container and a bare `node` process).
The second one finds every lock taken and does nothing.

---

## Safety switches

Every job that writes to the outside world has switches, so you can try it without risk. Each is a
setting in `doppelganger.toml` (`dry_run = true` under `[exec]`). To try one for a single run, set
the variable instead: it beats the file, and nothing in the file changes.

- `EXEC_DRY_RUN=1`: do nothing for real, only log.
- `EXEC_NO_MERGE=1`: do everything except the merge.
- `EXEC_MAX=0`: a free test that picks issues but runs no agent.
- `<NAME>_DB=/tmp/x.db`: point a job's database at a throwaway file.

The nightly job has the same ladder. Try `NIGHTLY_SANDCASTLE_MAX=0 npm run job nightly-sandcastle`
first (free, no agent), then `NIGHTLY_SANDCASTLE_DRY_RUN=1`, then `NIGHTLY_SANDCASTLE_MAX=1`.

---

## Install it in your repo

A repo with a `package.json` can install doppelganger as a package. It then runs the engine, adds
its own plugins and turns built-in plugins off. Nothing goes to a registry: you install from a git
URL, a folder or a tarball.

Which one to pick:

- **Install it** when you want your repo's own plugins, or want the engine version pinned in the
  repo's lockfile. The engine lives in the repo's `node_modules`, so the container needs no
  separate engine mount.
- **Use the standalone runner** (the next section) when one engine checkout should serve many
  repos, when a repo is not a Node project, or when you work on the engine itself.
- **Use the image** ("Run it from the image") when the repo needs only the built-in plugins and you want
  nothing but Docker on the machine.

### Install it and set it up

In your repo:

    npm install -D github:hyhilman/doppelganger#dev
    npx doppelganger init

That installs a branch. To pin a version, install a release instead (see "Releases"). `init` then
writes a compose file that pulls the published image of that version, where a branch install builds
the image on your machine.

`init` does what it does for the standalone runner (see "Set a repo up" below), with two changes. You
run it inside the repo, so it needs no path. And the engine is `node_modules/doppelganger`, a
folder the repo mount already covers, so the compose file has no engine mount. Add `INIT_DRY_RUN=1`
first to see what it would do. Then follow the steps it prints. Init writes `doppelganger.toml`, which you
commit, and `doppelganger.secret.toml`, which git ignores and which holds your tokens.

Other ways to install:

- A tarball. In an engine checkout run `npm pack`, then in your repo `npm install -D <path to the .tgz>`.
- A folder. `npm install -D <path to the checkout>` only links the folder. The engine code is built
  by `npm run build`, and the link finds its libraries in the checkout, so run `npm install` and
  `npm run build` in the checkout first.

The package is private, so `npm publish` fails on purpose. `npm run build` compiles the engine into
`dist/`, because Node does not strip types under `node_modules`. `npm pack` and a git install run it
for you. While you work on the engine itself, nothing is built: Node runs the TypeScript files.

### The commands

    npx doppelganger init            set the repo up (once)
    npx doppelganger config migrate  move an old setup: .env or a one-file doppelganger.toml, and creds/
    npx doppelganger --list          the jobs this repo runs, built-in and attached
    npx doppelganger job <name>      run one job by hand
    npx doppelganger up              run the supervisor on this machine
    npx doppelganger version         print the release version of this engine, or with --images the pi image of it (a checkout has neither)
    npx doppelganger skills sync     render the skills this repo runs into .claude/skills
    npx doppelganger crontab sync    install the watchdog on the machine's crontab
    npx doppelganger lease-clear     free a lease by hand
    npx doppelganger dlq             list or revive the rows that died
    npx doppelganger help            this list

`up` runs the supervisor on the host. The container does the same job: use
`docker compose -f .doppelganger/compose.yml up -d`. Run one of the two, never both.

`npx doppelganger config check` runs the checks of the settings that the supervisor makes at boot, and
starts nothing. It prints one `config-problem:` line for each problem, and never a value. It exits 1 when
it finds one.

The settings come from `doppelganger.toml` and `doppelganger.secret.toml` in the repo, and a variable
of the same name beats both files for one run, as with `npm run job`. The repo is the current folder; `ENGINE_ROOT` names another.

### Add your own plugin

List your plugins in one file at the top of the repo, `doppelganger.config.ts`. The engine imports
that file when it starts, and nothing else: it never scans a folder. The file and your plugins are
TypeScript in your repo, so Node runs them as they are. Set `"type": "module"` in your
`package.json`.

    import { defineConfig } from "doppelganger/plugin";
    import hello from "./tools/hello/plugin.ts";

    export default defineConfig({ plugins: [hello] });

A plugin is a manifest with its jobs. This one has one job that runs plain code:

    import { definePlugin } from "doppelganger/plugin";
    import { defineJob } from "doppelganger/ports/job";

    const greet = defineJob({
      name: "ops-hello-greet",
      description: "Write one line to the log",
      plugin: "hello",
      permissionMode: "auto",
      exec: async (ctx) => {
        ctx.log.info("hello", { from: "my own plugin" });
      },
    });

    export default definePlugin({
      name: "hello",
      kill: [],
      sources: [],
      routes: [],
      jobs: [greet],
      schedule: [],
      env: [],
      dir: import.meta.dirname,
    });

Then `npx doppelganger --list` shows `ops-hello-greet` with the mark "attached", and
`npx doppelganger job ops-hello-greet` runs it. Its databases and logs go in your repo
(`.doppelganger/`), never in `node_modules`.

An attached plugin follows the same rules as a built-in one. The engine checks them when it loads
the file, and refuses to start with the list of what is wrong:

- The plugin name is lower case, and no other plugin has it. `dir` is the plugin's own folder, so
  write `import.meta.dirname`.
- A job name starts with a stage prefix: `source-`, `triage-`, `backlog-`, `watch-`, `todo-`,
  `corpus-`, `nightly-`, `retro-` or `ops-`. No other job has the name. A job has a skill, code
  (`exec`) or both.
- One skill per job. A skill lives in `skills/<job>/SKILL.md` inside the plugin's folder, and no
  folder is left over without a job.
- Every setting is a row with a one-line `why`. A kill switch is named in capitals: the plugin, then
  NO, then the feature, joined by underscores. Build it with `killSwitch`.
- `schedule` stays `[]`. The supervisor's schedule is the engine's own list, and an attached plugin
  has no place in it yet. Run its jobs with `doppelganger job`, or from your own cron.

Your plugins can import `doppelganger/plugin` and `doppelganger/ports/*` and nothing else. A deep
import of any other path fails on purpose.

### Turn plugins off

`plugins` in the repo's `doppelganger.toml` names the plugins that run, built-in and attached. Leave it
out and every plugin runs, except `nightly` and `git`, which only fit the engine's own source. `init`
sets `plugins = ["todo", "ops"]`, because the other built-in plugins need settings of their own. To run
your plugin as well, add its name: `plugins = ["todo", "ops", "hello"]`. See "Choose which plugins
run" for the rest of the rules. `npx doppelganger --list` ends with the plugins `plugins` leaves out.

### Upgrade

For a release, follow "Releases / Upgrade" below. For a branch install, install again (`npm update
doppelganger`, or `npm install -D github:hyhilman/doppelganger#dev` for a newer branch), then restart: `docker compose -f .doppelganger/compose.yml down` and `up -d`.
If the `Dockerfile` changed, build the image again. If `.nvmrc` changed, the image has a new
name: delete the compose file and run `init` again.

---

## Run it on your other repos

The picture: you have a few repos, say five. You want one doppelganger for each, and each one
works only the issues of its own repo. You keep one copy of the engine (this checkout). Every repo
gets its own compose file, its own container and its own settings. If the repo is a Node project and
should carry its own copy of the engine, or its own plugins, install the package instead (see
"Install it in your repo"). If the machine should hold no engine checkout at all, run from the image
(see "Run it from the image").

    ~/projects/doppelganger/     the engine: one checkout, shared by every repo, mounted read-only
    ~/code/api/                  a repo
        doppelganger.toml          its shared settings: committed, no secret in it
        doppelganger.secret.toml   its tokens: not committed, mode 600
        .doppelganger/creds/       its logins
        .doppelganger/compose.yml  its compose file: this one file starts it
    ~/code/web/                  another repo, set up the same way

All the containers use one image, which is built from the engine. Each container has its own
name, its own lease database, its own logs and its own watchdog entry. The name is the `INSTANCE`
of the repo: its folder name, unless `instance` in its `doppelganger.toml` sets another. Two repos with
the same folder name need different `instance` rows.

### Set a repo up

Run this once per repo, from the engine checkout:

    npm run init -- ~/code/api

Add `INIT_DRY_RUN=1` first to see what it would do without writing anything. Init:

- writes `.doppelganger/compose.yml` in the repo, with this machine's real paths in it. Git
  ignores it. Delete it and run init again if you move the engine or the repo, or if `.nvmrc`
  changes (the compose file names the image by its Node version);
- writes `doppelganger.toml` from `doppelganger.example.toml`, in mode 644: commit it, since it holds
  no secret. It sets `tracker` (from the `origin` remote) and `base` (the remote's default branch)
  under `[exec]`, `plugins = ["todo", "ops"]` and `dry_run = true`. Everything else stays as the
  example has it. If the repo already has a `doppelganger.toml`, init leaves it alone and lists the
  lines to add;
- writes `doppelganger.secret.toml` from `doppelganger.secret.example.toml`, in mode 600. It sets
  nothing: it is the place for your tokens;
- adds `doppelganger.secret.toml`, `.doppelganger/` and `.worktrees/` to the repo's `.gitignore`,
  when they are not there. It does not add `doppelganger.toml`: that file is committed. If an older
  init added a `doppelganger.toml` line, init says so and leaves the line for you to remove. It does
  not add `.env` either: the repo may have its own app `.env`, and that is not ours to ignore;
- creates the tracker labels the loop uses, with your own `gh` login. A label that exists stays
  as it is.

Init never overwrites a file, so running it again changes nothing. Then it prints the next steps
with your real paths. They are these:

1. Make a GitHub login for the repo. Each repo has its own `.doppelganger/creds/`, so `ENGINE_ROOT` names it:

        ENGINE_ROOT=~/code/api bin/creds.sh add gh my-github
        ENGINE_ROOT=~/code/api bin/creds.sh gh-login my-github

   Set `gh = "my-github"` and `humans` under `[exec]` in the repo's `doppelganger.toml`. Set
   `test_cmd` to the repo's test command. To run on pi or codex, make the model logins with
   `bin/creds.sh add pi` or `bin/creds.sh add codex`, and add a `[[exec.executor]]`,
   `[[exec.reviewer]]` and `[[exec.smart]]` entry that names each (see "Credentials" above). Init adds
   none, and without them every role runs on claude. An OAuth login is made once per repo.
   Commit `doppelganger.toml`. Put a token, such as `token` under `[ntfy]`, in `doppelganger.secret.toml`
   instead: the supervisor refuses to start when `doppelganger.toml` holds one.
2. Start it. The first start builds the image if it is missing; the other repos reuse it:

        docker compose -f ~/code/api/.doppelganger/compose.yml up -d

   It runs in dry run: it reads the issues and logs what it would do. When the log looks right, set
   `dry_run = false` under `[exec]` in the repo's `doppelganger.toml`.
3. Install the watchdog. It is one crontab entry per repo, named after the repo's instance:

        cd ~/projects/doppelganger
        ENGINE_ROOT=~/code/api CRONTAB_CMD=$(command -v crontab) npm run crontab sync

Day to day, use the repo's compose file: `docker compose -f ~/code/api/.doppelganger/compose.yml logs -f`,
and the same with `down` or `up -d`. A change to `doppelganger.toml` is read by the next round, except
`plugins`, which needs `down` and `up -d`. `ENGINE_ROOT=~/code/api bin/fleet.sh status` shows the
facts the container starts with.

### Upgrade

The engine is not in the image, so an upgrade is a pull:

1. `git pull` in the engine checkout.
2. If the `Dockerfile` changed, rebuild the image once with `docker compose -f <any repo's compose file> build`.
   If `.nvmrc` changed, the image has a new name: delete each repo's compose file and run init again.
3. Restart each repo with `down` and then `up -d` on its compose file. The container then runs the
   new engine code.

### What a repo does not run

`nightly` and `git` only fit the engine's own source. `nightly` runs `npm test` and the engine's
job runner and edits the docs in the folder it works. The `git` plugin's `ops-self-sync` pulls the
checkout the supervisor runs from, and that is the engine. In a repo, a `plugins` list that names
either is refused when the supervisor starts, with the reason. A repo that leaves `plugins` out runs
every other plugin. Init sets `todo,ops`, which is the issue loop and the lease cleanup.

---

## Releases

CI makes two kinds of release. A push to `dev` makes a dev build. A push to `main` makes the stable
version. A release is made only after `npm test` passed on that same commit.

- **dev**, from the `dev` branch: version `0.1.0-dev.1`, then `0.1.0-dev.2`, and so on. It is a
  GitHub pre-release.
- **stable**, from `main`: version `0.1.0`. It is a normal GitHub release.

The number before `-dev` is the base. It is the `version` in `package.json`. A person raises it, with
the bump command below. CI never changes it. The dev build number is one more than the highest dev tag of that base.

Each release has three things:

- a git tag, `v` and the version (`v0.1.0-dev.3`). The tag sits on a commit made for the release:
  the pushed commit plus a `package.json` that holds the exact version and the names of the images.
  Only the tag is pushed. `dev` and `main` do not move, so CI does not start again;
- the package, as a tarball on the GitHub release;
- two images on ghcr.io: the supervisor and the pi runner. They carry the version as their tag. A
  dev build also moves the tag `dev`, and a stable release moves the tag `latest`. The supervisor image
  carries the engine of that version, which is what "Run it from the image" runs. No release publishes
  the codex image.

The base must be exactly one step above the last stable release, which is the highest `v` and
three numbers tag. A step is one of three:

- patch: `0.1.0` to `0.1.1`;
- minor: `0.1.0` to `0.2.0` (the patch goes back to 0);
- major: `0.1.0` to `1.0.0` (the minor and the patch go back to 0).

Before the first stable release, the last one counts as `0.0.0`. CI checks this on every push to
`dev` and to `main`, so a bad base fails on `dev` and cannot reach `main`. A skip (`0.1.0` to
`0.3.0`), a missing reset (`0.1.0` to `0.2.5`), a step back, and a version that is already released
all fail. The message names the last stable tag, the base it found and the three allowed versions.
Dev build tags never count as the last stable release.

### Log in once

The repo and the images are private. Installing the package uses your git login. Pulling an image
needs a login to ghcr.io. Run this once on each machine, with your GitHub user name and a token
that has the `read:packages` scope:

    docker login ghcr.io

### Install a version

To run from the image instead of installing anything, see "Run it from the image". To install the package:

    npm install -D github:hyhilman/doppelganger#v0.1.0-dev.3
    npx doppelganger init

Use `#v0.1.0` for a stable version. Or install from the tarball of the release:

    gh release download v0.1.0-dev.3 --repo hyhilman/doppelganger --pattern '*.tgz'
    npm install -D ./doppelganger-0.1.0-dev.3.tgz

Both report the exact version in their `package.json`. A branch install (`#dev`, `#main`) is not a
release: no image was built for it, so `init` writes a compose file that builds the image on your
machine.

`init` writes a compose file that names the supervisor image of that exact version. Its next steps
tell you to pull that image and the pi image of the same version. Pull the pi image on the host
yourself. The container starts pi passes through the host's docker and has no ghcr.io login of its
own. With `image` under `[runner.pi]` unset, a release runs the pi image of its own version. An engine checkout
runs its local build, as before. No release publishes a codex image: on each machine that runs a codex
entry, build it with `bin/runner.sh build codex`.

### Upgrade

1. Install the new version, as above.
2. Delete `.doppelganger/compose.yml` and run `npx doppelganger init` again. It writes the compose
   file with the new image and leaves your settings files alone. Or edit the version in the image line by hand.
3. Pull the new images: the supervisor with compose, and the pi image with the `docker pull` line
   that `init` prints:

        docker compose -f .doppelganger/compose.yml pull

4. Restart: `docker compose -f .doppelganger/compose.yml up -d`.

### Raise the base

Do this on `dev` right after a stable release. The tool reads the last stable tag from your local
tags, so fetch them first, then pick a kind:

    git fetch --tags && npm run release -- bump <kind>

`<kind>` is `patch`, `minor` or `major`. The tool writes the next version into the root
`package.json`, every workspace `package.json` and the lockfile. Commit them. It refuses if the base
is already one step above the last stable release, so two bumps before a release cannot skip a
number. The next push to `dev` then makes the first dev build of the new base, for example
`0.2.0-dev.1`.

Which one to pick:

- While the version starts with `0.`: `minor` for a breaking change or a new feature, and `patch`
  for fixes only.
- `major` makes `1.0.0`. Pick it once the plugin API and the settings are stable.

To see what the next release would be, fetch the tags and ask the release tool. It writes nothing:

    git fetch --tags
    npm run release -- plan --branch dev

`RELEASE_DRY_RUN=1` does the same for `bump` and `publish`: they print the files, and for `publish`
the tag, tarball and release, that they would make, and make none of them.

---

## Without Docker

You can run the supervisor straight on the machine instead of in the container:

    node host/supervisor.ts

It does not restart itself, so run it under systemd, pm2 or a restart loop. It reads
`doppelganger.toml` and `doppelganger.secret.toml` in the repo folder itself, and so does every job it
starts, so there is nothing to load into your shell first. The commands that run once, such as
`npm run crontab sync`, read the same files. A variable set in your shell beats them.

---

## For developers

- `npm test` runs every test, including a type check. Run it before you commit.
- `CLAUDE.md` explains the code layout and the rules the tests enforce.
- `roadmap.md` is the full feature list and plan. It is kept out of git.
- The code is in four places: `kernel/` (the framework), `plugins/` (the jobs), `host/` (the app
  that wires them up) and `cli/` (small command-line tools).
